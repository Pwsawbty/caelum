import React, { useMemo } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { Post } from '../../types';
import { PostCard } from './PostCard';
import { SPACING, LAYOUT } from '../../constants';

const { width } = Dimensions.get('window');

interface MasonryGridProps {
  posts: Post[];
  onPostPress: (post: Post) => void;
}

export const MasonryGrid: React.FC<MasonryGridProps> = ({ posts, onPostPress }) => {
  // Split posts into 2 columns
  const columns = useMemo(() => {
    const left: Post[] = [];
    const right: Post[] = [];
    posts.forEach((post, index) => {
      if (index % 2 === 0) left.push(post);
      else right.push(post);
    });
    return [left, right];
  }, [posts]);

  return (
    <View style={styles.container}>
      {columns.map((column, colIdx) => (
        <View key={colIdx} style={styles.column}>
          {column.map((post, postIdx) => (
            <PostCard
              key={post.id}
              post={post}
              onPress={onPostPress}
              columnIndex={colIdx}
            />
          ))}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
  },
  column: {
    flex: 1,
    gap: SPACING.sm,
  },
});
