import React, { useCallback } from 'react';
import {
  TouchableOpacity,
  View,
  Dimensions,
  StyleSheet,
} from 'react-native';
import { Image } from 'expo-image';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Post } from '../../types';
import { CaelumText } from '../common/CaelumText';
import { Avatar } from '../common/Avatar';
import { COLORS, SPACING, RADIUS, CATEGORY_COLORS, LAYOUT } from '../../constants';

const { width } = Dimensions.get('window');
const COLUMN_WIDTH = (width - SPACING.md * 3) / LAYOUT.numColumns;

interface PostCardProps {
  post: Post;
  onPress: (post: Post) => void;
  columnIndex?: number;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onPress, columnIndex = 0 }) => {
  const scale = useSharedValue(1);

  // Staggered heights for masonry feel
  const cardHeight = columnIndex % 2 === 0
    ? COLUMN_WIDTH * 1.4
    : COLUMN_WIDTH * 1.7;

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = useCallback(() => {
    scale.value = withSpring(0.96, { damping: 15, stiffness: 300 });
  }, []);

  const handlePressOut = useCallback(() => {
    scale.value = withSpring(1, { damping: 15, stiffness: 300 });
  }, []);

  const categoryColor = CATEGORY_COLORS[post.category] || COLORS.aurora.blue;

  return (
    <Animated.View style={[animatedStyle, styles.wrapper]}>
      <TouchableOpacity
        onPress={() => onPress(post)}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        activeOpacity={1}
      >
        <View style={[styles.card, { height: cardHeight }]}>
          {/* Thumbnail */}
          <Image
            source={{ uri: post.thumbnail_url || post.image_url }}
            style={StyleSheet.absoluteFillObject}
            contentFit="cover"
            transition={400}
            placeholder={{ thumbhash: undefined }}
          />

          {/* Bottom gradient overlay */}
          <LinearGradient
            colors={['transparent', 'rgba(5,5,7,0.92)']}
            locations={[0.4, 1]}
            style={styles.gradient}
          />

          {/* Category badge */}
          <View style={[styles.categoryBadge, { borderColor: categoryColor + '40' }]}>
            <CaelumText
              variant="label"
              style={{ color: categoryColor, letterSpacing: 0.5 }}
            >
              {post.category}
            </CaelumText>
          </View>

          {/* Content overlay */}
          <View style={styles.content}>
            <CaelumText
              variant="caption"
              weight="semibold"
              style={styles.title}
              numberOfLines={2}
            >
              {post.title}
            </CaelumText>

            {post.author && (
              <View style={styles.creator}>
                <Avatar
                  uri={post.author.profile_photo}
                  displayName={post.author.display_name}
                  size={18}
                />
                <CaelumText variant="label" color="muted" style={styles.creatorName}>
                  {post.author.display_name || post.author.username}
                </CaelumText>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    width: COLUMN_WIDTH,
    marginBottom: SPACING.sm,
  },
  card: {
    width: COLUMN_WIDTH,
    borderRadius: RADIUS.lg,
    overflow: 'hidden',
    backgroundColor: COLORS.obsidianLight,
  },
  gradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '65%',
  },
  categoryBadge: {
    position: 'absolute',
    top: SPACING.sm,
    left: SPACING.sm,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 3,
    backgroundColor: 'rgba(5,5,7,0.6)',
    borderRadius: RADIUS.full,
    borderWidth: 1,
  },
  content: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: SPACING.sm,
  },
  title: {
    color: COLORS.offWhite,
    lineHeight: 17,
    marginBottom: SPACING.xs,
  },
  creator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
  },
  creatorName: {
    fontSize: 10,
  },
});
