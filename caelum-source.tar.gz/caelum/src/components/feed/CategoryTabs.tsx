import React, { useRef } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Animated,
} from 'react-native';
import { Category } from '../../types';
import { CATEGORIES, CATEGORY_COLORS, COLORS, RADIUS, SPACING } from '../../constants';
import { CaelumText } from '../common/CaelumText';

interface CategoryTabsProps {
  selected: Category | null;
  onSelect: (category: Category | null) => void;
}

export const CategoryTabs: React.FC<CategoryTabsProps> = ({ selected, onSelect }) => {
  const allCategories: (Category | null)[] = [null, ...CATEGORIES];

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      {allCategories.map((cat) => {
        const isSelected = cat === selected;
        const color = cat ? CATEGORY_COLORS[cat] : COLORS.offWhite;

        return (
          <TouchableOpacity
            key={cat || 'all'}
            onPress={() => onSelect(cat)}
            activeOpacity={0.7}
            style={[
              styles.tab,
              isSelected && {
                backgroundColor: color + '18',
                borderColor: color + '50',
              },
            ]}
          >
            <CaelumText
              variant="label"
              weight={isSelected ? 'semibold' : 'regular'}
              style={[
                styles.tabText,
                { color: isSelected ? color : COLORS.mistSoft },
              ]}
            >
              {cat || 'All'}
            </CaelumText>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    gap: SPACING.sm,
    flexDirection: 'row',
  },
  tab: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 2,
    borderRadius: RADIUS.full,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    backgroundColor: COLORS.obsidianLight,
  },
  tabText: {
    letterSpacing: 0.3,
    fontSize: 12,
  },
});
