import React, { useRef, useState, useCallback } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
  Share,
  StatusBar,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Post } from '../../types';
import { CaelumText } from '../common/CaelumText';
import { Avatar } from '../common/Avatar';
import { GlassPanel } from '../common/GlassPanel';
import { COLORS, SPACING, RADIUS, CATEGORY_COLORS } from '../../constants';
import { toggleFollow } from '../../services/user.service';
import { useAuthStore } from '../../store/auth.store';

const { width, height } = Dimensions.get('window');
const IMAGE_HEIGHT = height * 0.55;

interface PostViewerProps {
  post: Post;
  onClose?: () => void;
}

export const PostViewer: React.FC<PostViewerProps> = ({ post, onClose }) => {
  const { user } = useAuthStore();
  const [isFollowing, setIsFollowing] = useState(post.is_following_author || false);
  const [isSaved, setIsSaved] = useState(false);
  const [promptCopied, setPromptCopied] = useState(false);

  const scrollY = useSharedValue(0);

  const imageStyle = useAnimatedStyle(() => ({
    transform: [
      {
        translateY: interpolate(
          scrollY.value,
          [-IMAGE_HEIGHT, 0, IMAGE_HEIGHT],
          [-IMAGE_HEIGHT * 0.3, 0, IMAGE_HEIGHT * 0.3],
          Extrapolate.CLAMP
        ),
      },
    ],
  }));

  const handleFollow = async () => {
    if (!user || !post.author) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const { isFollowing: newState } = await toggleFollow(user.id, post.author.id);
    setIsFollowing(newState);
  };

  const handleSave = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIsSaved(!isSaved);
  };

  const handleCopyPrompt = async () => {
    // In a real app, use Clipboard from @react-native-clipboard/clipboard
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setPromptCopied(true);
    setTimeout(() => setPromptCopied(false), 2000);
  };

  const handleCreatorPress = () => {
    if (post.author) {
      router.push(`/profile/${post.author.id}`);
    }
  };

  const categoryColor = CATEGORY_COLORS[post.category] || COLORS.aurora.blue;

  return (
    <View style={styles.container}>
      <StatusBar hidden />

      {/* Scrollable content */}
      <Animated.ScrollView
        style={styles.scroll}
        showsVerticalScrollIndicator={false}
        onScroll={(e) => {
          scrollY.value = e.nativeEvent.contentOffset.y;
        }}
        scrollEventThrottle={16}
      >
        {/* IMAGE SECTION */}
        <View style={styles.imageContainer}>
          <Animated.View style={[StyleSheet.absoluteFillObject, imageStyle]}>
            <Image
              source={{ uri: post.image_url }}
              style={{ width, height: IMAGE_HEIGHT + 60 }}
              contentFit="cover"
              transition={500}
            />
          </Animated.View>

          {/* Gradient overlay bottom */}
          <LinearGradient
            colors={['transparent', COLORS.void]}
            locations={[0.55, 1]}
            style={styles.imageGradient}
          />
        </View>

        {/* CONTENT PANEL */}
        <View style={styles.contentWrapper}>
          {/* Creator Row */}
          <TouchableOpacity
            style={styles.creatorRow}
            onPress={handleCreatorPress}
            activeOpacity={0.8}
          >
            <Avatar
              uri={post.author?.profile_photo}
              displayName={post.author?.display_name}
              size={44}
            />
            <View style={{ flex: 1, marginLeft: SPACING.md }}>
              <CaelumText weight="semibold" style={{ color: COLORS.offWhite }}>
                {post.author?.display_name || post.author?.username || 'Unknown'}
              </CaelumText>
              <CaelumText variant="caption" color="muted">
                @{post.author?.username}
              </CaelumText>
            </View>

            {user?.id !== post.author?.id && (
              <TouchableOpacity
                onPress={handleFollow}
                style={[
                  styles.followButton,
                  isFollowing && styles.followingButton,
                ]}
              >
                <CaelumText
                  variant="caption"
                  weight="semibold"
                  style={{
                    color: isFollowing ? COLORS.mistLight : COLORS.void,
                  }}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </CaelumText>
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          {/* Title */}
          <CaelumText
            variant="heading"
            weight="semibold"
            style={styles.title}
          >
            {post.title}
          </CaelumText>

          {/* Meta badges */}
          <View style={styles.metaRow}>
            <View style={[styles.badge, { borderColor: categoryColor + '40' }]}>
              <CaelumText variant="label" style={{ color: categoryColor }}>
                {post.category}
              </CaelumText>
            </View>
            <View style={styles.badge}>
              <CaelumText variant="label" color="muted">
                {post.tool_used}
              </CaelumText>
            </View>
          </View>

          {/* Description */}
          {post.description && (
            <CaelumText
              variant="body"
              color="secondary"
              style={styles.description}
            >
              {post.description}
            </CaelumText>
          )}

          {/* Divider */}
          <View style={styles.divider} />

          {/* Prompt Section */}
          <GlassPanel style={styles.promptPanel}>
            <View style={styles.promptHeader}>
              <CaelumText variant="label" weight="semibold" color="muted" style={{ letterSpacing: 1 }}>
                PROMPT
              </CaelumText>
              <TouchableOpacity
                onPress={handleCopyPrompt}
                style={styles.copyButton}
              >
                <Ionicons
                  name={promptCopied ? 'checkmark' : 'copy-outline'}
                  size={14}
                  color={promptCopied ? COLORS.aurora.teal : COLORS.mistLight}
                />
                <CaelumText
                  variant="label"
                  style={{
                    color: promptCopied ? COLORS.aurora.teal : COLORS.mistLight,
                    marginLeft: 4,
                  }}
                >
                  {promptCopied ? 'Copied!' : 'Copy'}
                </CaelumText>
              </TouchableOpacity>
            </View>
            <CaelumText
              variant="body"
              style={styles.promptText}
            >
              {post.prompt}
            </CaelumText>
          </GlassPanel>

          {/* Workflow Section */}
          {post.workflow && (
            <>
              <View style={styles.divider} />
              <CaelumText variant="label" weight="semibold" color="muted" style={styles.sectionLabel}>
                WORKFLOW
              </CaelumText>
              <CaelumText variant="body" color="secondary" style={{ lineHeight: 22 }}>
                {post.workflow}
              </CaelumText>
            </>
          )}

          {/* External link */}
          {post.external_link && (
            <View style={styles.externalLink}>
              <Ionicons name="link-outline" size={14} color={COLORS.aurora.blue} />
              <CaelumText
                variant="caption"
                style={{ color: COLORS.aurora.blue, marginLeft: 6 }}
                numberOfLines={1}
              >
                {post.external_link}
              </CaelumText>
            </View>
          )}

          {/* Bottom padding */}
          <View style={{ height: 100 }} />
        </View>
      </Animated.ScrollView>

      {/* Floating top controls */}
      <View style={styles.topControls}>
        <TouchableOpacity
          onPress={onClose || (() => router.back())}
          style={styles.topButton}
        >
          <BlurView intensity={30} tint="dark" style={styles.topButtonInner}>
            <Ionicons name="close" size={20} color={COLORS.offWhite} />
          </BlurView>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={handleSave}
          style={styles.topButton}
        >
          <BlurView intensity={30} tint="dark" style={styles.topButtonInner}>
            <Ionicons
              name={isSaved ? 'bookmark' : 'bookmark-outline'}
              size={20}
              color={isSaved ? COLORS.aurora.amber : COLORS.offWhite}
            />
          </BlurView>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  scroll: {
    flex: 1,
  },
  imageContainer: {
    height: IMAGE_HEIGHT,
    overflow: 'hidden',
  },
  imageGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: IMAGE_HEIGHT * 0.5,
  },
  contentWrapper: {
    padding: SPACING.xl,
    paddingTop: SPACING.lg,
  },
  creatorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.xl,
  },
  followButton: {
    backgroundColor: COLORS.offWhite,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.xs + 2,
    borderRadius: RADIUS.full,
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  title: {
    marginBottom: SPACING.md,
    lineHeight: 32,
  },
  metaRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
  },
  badge: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.full,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    backgroundColor: COLORS.obsidianLight,
  },
  description: {
    lineHeight: 24,
    marginBottom: SPACING.lg,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.glassBorder,
    marginVertical: SPACING.xl,
  },
  promptPanel: {
    padding: SPACING.lg,
    borderRadius: RADIUS.xl,
  },
  promptHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  copyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.sm,
    backgroundColor: COLORS.obsidianLight,
  },
  promptText: {
    color: COLORS.mistLight,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  sectionLabel: {
    letterSpacing: 1,
    marginBottom: SPACING.md,
  },
  externalLink: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: SPACING.xl,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.lg,
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    borderColor: `${COLORS.aurora.blue}30`,
  },
  topControls: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 30,
    left: SPACING.lg,
    right: SPACING.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  topButton: {
    borderRadius: RADIUS.full,
    overflow: 'hidden',
  },
  topButtonInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(5,5,7,0.5)',
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
});
