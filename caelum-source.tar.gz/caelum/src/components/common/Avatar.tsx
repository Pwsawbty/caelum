import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Image } from 'expo-image';
import { CaelumText } from './CaelumText';
import { COLORS, RADIUS } from '../../constants';

interface AvatarProps {
  uri?: string;
  displayName?: string;
  size?: number;
}

export const Avatar: React.FC<AvatarProps> = ({ uri, displayName, size = 40 }) => {
  const initials = displayName
    ? displayName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : '?';

  return (
    <View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
        },
      ]}
    >
      {uri ? (
        <Image
          source={{ uri }}
          style={{ width: size, height: size, borderRadius: size / 2 }}
          contentFit="cover"
          transition={300}
        />
      ) : (
        <CaelumText
          style={{ fontSize: size * 0.35, color: COLORS.offWhite, fontWeight: '600' }}
        >
          {initials}
        </CaelumText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.obsidianLight,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    overflow: 'hidden',
  },
});
