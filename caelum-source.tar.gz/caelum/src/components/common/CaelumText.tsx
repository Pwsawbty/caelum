import React from 'react';
import { Text, TextProps, StyleSheet } from 'react-native';
import { COLORS, FONT_SIZES } from '../../constants';

type TextVariant = 'display' | 'heading' | 'title' | 'body' | 'caption' | 'label' | 'mono';
type TextWeight = 'light' | 'regular' | 'medium' | 'semibold' | 'bold';
type TextColor = 'primary' | 'secondary' | 'muted' | 'accent' | 'white';

interface CaelumTextProps extends TextProps {
  variant?: TextVariant;
  weight?: TextWeight;
  color?: TextColor;
}

const FONT_WEIGHT_MAP: Record<TextWeight, '300' | '400' | '500' | '600' | '700'> = {
  light: '300',
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

const COLOR_MAP: Record<TextColor, string> = {
  primary: COLORS.offWhite,
  secondary: COLORS.mistLight,
  muted: COLORS.mistSoft,
  accent: COLORS.aurora.blue,
  white: '#FFFFFF',
};

const SIZE_MAP: Record<TextVariant, number> = {
  display: FONT_SIZES['3xl'],
  heading: FONT_SIZES['2xl'],
  title: FONT_SIZES.lg,
  body: FONT_SIZES.base,
  caption: FONT_SIZES.sm,
  label: FONT_SIZES.xs,
  mono: FONT_SIZES.sm,
};

export const CaelumText: React.FC<CaelumTextProps> = ({
  variant = 'body',
  weight = 'regular',
  color = 'primary',
  style,
  children,
  ...props
}) => {
  return (
    <Text
      style={[
        {
          fontSize: SIZE_MAP[variant],
          fontWeight: FONT_WEIGHT_MAP[weight],
          color: COLOR_MAP[color],
          letterSpacing: variant === 'display' ? -1 : variant === 'label' ? 0.5 : 0,
        },
        style,
      ]}
      {...props}
    >
      {children}
    </Text>
  );
};
