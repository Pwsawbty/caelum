import React from 'react';
import { View, StyleSheet } from 'react-native';
import { CaelumText } from './CaelumText';
import { COLORS, SPACING } from '../../constants';

interface EmptyStateProps {
  icon?: string;
  title: string;
  message?: string;
  action?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = '✦',
  title,
  message,
  action,
}) => {
  return (
    <View style={styles.container}>
      <CaelumText style={styles.icon}>{icon}</CaelumText>
      <CaelumText variant="title" weight="medium" style={styles.title}>
        {title}
      </CaelumText>
      {message && (
        <CaelumText
          variant="body"
          color="muted"
          style={styles.message}
        >
          {message}
        </CaelumText>
      )}
      {action && <View style={styles.action}>{action}</View>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING['3xl'],
  },
  icon: {
    fontSize: 40,
    marginBottom: SPACING.xl,
    opacity: 0.4,
  },
  title: {
    textAlign: 'center',
    marginBottom: SPACING.sm,
  },
  message: {
    textAlign: 'center',
    lineHeight: 22,
  },
  action: {
    marginTop: SPACING.xl,
  },
});
