import React, { useState } from 'react';
import {
  TextInput,
  View,
  TouchableOpacity,
  TextInputProps,
  StyleSheet,
} from 'react-native';
import { CaelumText } from './CaelumText';
import { COLORS, RADIUS, SPACING } from '../../constants';

interface CaelumInputProps extends TextInputProps {
  label?: string;
  error?: string;
  hint?: string;
  rightElement?: React.ReactNode;
}

export const CaelumInput: React.FC<CaelumInputProps> = ({
  label,
  error,
  hint,
  rightElement,
  style,
  ...props
}) => {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <View style={styles.wrapper}>
      {label && (
        <CaelumText variant="label" weight="medium" color="muted" style={styles.label}>
          {label}
        </CaelumText>
      )}
      <View
        style={[
          styles.container,
          isFocused && styles.focused,
          error ? styles.error : {},
        ]}
      >
        <TextInput
          placeholderTextColor={COLORS.mistFaint}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          style={[styles.input, style]}
          {...props}
        />
        {rightElement && (
          <View style={styles.rightElement}>{rightElement}</View>
        )}
      </View>
      {error && (
        <CaelumText variant="caption" style={{ color: COLORS.aurora.rose, marginTop: 4 }}>
          {error}
        </CaelumText>
      )}
      {hint && !error && (
        <CaelumText variant="caption" color="muted" style={{ marginTop: 4 }}>
          {hint}
        </CaelumText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: SPACING.lg,
  },
  label: {
    marginBottom: SPACING.xs,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    paddingHorizontal: SPACING.lg,
    minHeight: 52,
  },
  focused: {
    borderColor: 'rgba(255,255,255,0.2)',
  },
  error: {
    borderColor: COLORS.aurora.rose,
  },
  input: {
    flex: 1,
    color: COLORS.offWhite,
    fontSize: 15,
    fontWeight: '400',
    paddingVertical: SPACING.md,
  },
  rightElement: {
    marginLeft: SPACING.sm,
  },
});
