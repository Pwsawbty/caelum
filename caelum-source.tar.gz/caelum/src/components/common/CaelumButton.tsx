import React from 'react';
import {
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { CaelumText } from './CaelumText';
import { COLORS, RADIUS, SPACING } from '../../constants';

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'glass';

interface CaelumButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  isLoading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: ViewStyle;
  textStyle?: TextStyle;
  fullWidth?: boolean;
}

const VARIANT_STYLES: Record<ButtonVariant, ViewStyle> = {
  primary: {
    backgroundColor: COLORS.offWhite,
  },
  secondary: {
    backgroundColor: COLORS.obsidianLight,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  danger: {
    backgroundColor: 'rgba(244,63,94,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(244,63,94,0.3)',
  },
  glass: {
    backgroundColor: COLORS.glass,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
};

const VARIANT_TEXT_COLOR: Record<ButtonVariant, 'primary' | 'secondary' | 'muted' | 'accent' | 'white'> = {
  primary: 'white',
  secondary: 'primary',
  ghost: 'primary',
  danger: 'accent',
  glass: 'primary',
};

export const CaelumButton: React.FC<CaelumButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  isLoading = false,
  disabled = false,
  icon,
  style,
  textStyle,
  fullWidth = false,
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || isLoading}
      activeOpacity={0.7}
      style={[
        styles.base,
        VARIANT_STYLES[variant],
        fullWidth && { width: '100%' },
        (disabled || isLoading) && { opacity: 0.5 },
        style,
      ]}
    >
      {isLoading ? (
        <ActivityIndicator
          color={variant === 'primary' ? COLORS.void : COLORS.offWhite}
          size="small"
        />
      ) : (
        <>
          {icon}
          <CaelumText
            weight="medium"
            color={variant === 'primary' ? 'white' : VARIANT_TEXT_COLOR[variant]}
            style={[
              {
                fontSize: 15,
                color: variant === 'primary' ? '#050507' : undefined,
              },
              textStyle,
            ]}
          >
            {title}
          </CaelumText>
        </>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: SPACING.xl,
    paddingVertical: SPACING.md + 2,
    borderRadius: RADIUS.full,
  },
});
