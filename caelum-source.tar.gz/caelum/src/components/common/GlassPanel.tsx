import React from 'react';
import { View, ViewProps, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { COLORS, RADIUS } from '../../constants';

interface GlassPanelProps extends ViewProps {
  intensity?: number;
  borderRadius?: number;
  borderVisible?: boolean;
  backgroundColor?: string;
}

export const GlassPanel: React.FC<GlassPanelProps> = ({
  intensity = 20,
  borderRadius = RADIUS.xl,
  borderVisible = true,
  backgroundColor = 'rgba(10, 10, 18, 0.7)',
  style,
  children,
  ...props
}) => {
  return (
    <BlurView
      intensity={intensity}
      tint="dark"
      style={[
        {
          borderRadius,
          overflow: 'hidden',
          borderWidth: borderVisible ? 1 : 0,
          borderColor: COLORS.glassBorder,
          backgroundColor,
        },
        style,
      ]}
      {...props}
    >
      {children}
    </BlurView>
  );
};
