import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { CaelumText } from './CaelumText';
import { COLORS } from '../../constants';

const { width, height } = Dimensions.get('window');

interface LoadingScreenProps {
  message?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({
  message = 'Loading...',
}) => {
  const pulse = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1200,
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0.3,
          duration: 1200,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#050507', '#0a0a14', '#050507']}
        style={StyleSheet.absoluteFillObject}
      />
      <Animated.Text
        style={[styles.logo, { opacity: pulse }]}
      >
        ✦
      </Animated.Text>
      <CaelumText
        variant="heading"
        weight="light"
        style={styles.brand}
      >
        CAELUM
      </CaelumText>
      {message !== 'Loading...' && (
        <CaelumText variant="caption" color="muted" style={{ marginTop: 24 }}>
          {message}
        </CaelumText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    fontSize: 48,
    color: COLORS.offWhite,
    marginBottom: 16,
  },
  brand: {
    letterSpacing: 12,
    fontSize: 18,
    color: COLORS.mistLight,
  },
});
