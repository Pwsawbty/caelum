import { Category } from '../types';

// ─── Colors ──────────────────────────────────────────────────────────────────
export const COLORS = {
  void: '#050507',
  voidLight: '#0d0d12',
  obsidian: '#0f0f15',
  obsidianLight: '#161620',
  obsidianMid: '#1a1a25',
  obsidianSoft: '#1e1e2a',
  mistDefault: '#8b8fa8',
  mistLight: '#a8acc4',
  mistSoft: '#6b6f85',
  mistFaint: '#3d3f50',
  white: '#FFFFFF',
  offWhite: '#E8E8F0',
  aurora: {
    blue: '#4a7cf7',
    purple: '#8b5cf6',
    teal: '#14b8a6',
    rose: '#f43f5e',
    amber: '#f59e0b',
  },
  glass: 'rgba(255,255,255,0.04)',
  glassBorder: 'rgba(255,255,255,0.08)',
  glassStrong: 'rgba(255,255,255,0.10)',
  overlay: 'rgba(5,5,7,0.85)',
  overlayLight: 'rgba(5,5,7,0.5)',
} as const;

// ─── Typography ──────────────────────────────────────────────────────────────
export const FONTS = {
  light: 'System',
  regular: 'System',
  medium: 'System',
  semibold: 'System',
  bold: 'System',
} as const;

export const FONT_SIZES = {
  xs: 11,
  sm: 13,
  base: 15,
  md: 17,
  lg: 19,
  xl: 22,
  '2xl': 26,
  '3xl': 32,
  '4xl': 40,
} as const;

// ─── Spacing ─────────────────────────────────────────────────────────────────
export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  '2xl': 24,
  '3xl': 32,
  '4xl': 40,
  '5xl': 48,
  '6xl': 64,
} as const;

// ─── Border Radius ───────────────────────────────────────────────────────────
export const RADIUS = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 18,
  '2xl': 24,
  full: 999,
} as const;

// ─── Categories ──────────────────────────────────────────────────────────────
export const CATEGORIES: Category[] = [
  'Cinematic',
  'Dreamcore',
  'Rain',
  'Countryside',
  'Sci-fi',
  'Nature',
  'Warm',
  'Neon',
];

export const CATEGORY_COLORS: Record<Category, string> = {
  Cinematic: '#4a7cf7',
  Dreamcore: '#8b5cf6',
  Rain: '#14b8a6',
  Countryside: '#f59e0b',
  'Sci-fi': '#f43f5e',
  Nature: '#22c55e',
  Warm: '#f97316',
  Neon: '#a855f7',
};

// ─── Image Constraints ───────────────────────────────────────────────────────
export const IMAGE_CONSTRAINTS = {
  maxWidth: 1080,
  maxHeight: 1920,
  maxFileSizeBytes: 10 * 1024 * 1024, // 10MB
  allowedFormats: ['jpg', 'jpeg', 'png', 'webp'],
  allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
} as const;

// ─── Layout ──────────────────────────────────────────────────────────────────
export const LAYOUT = {
  headerHeight: 60,
  tabBarHeight: 70,
  columnGap: 8,
  numColumns: 2,
} as const;

// ─── Animation ───────────────────────────────────────────────────────────────
export const ANIMATION = {
  fast: 200,
  normal: 350,
  slow: 500,
  verySlow: 800,
} as const;

// ─── Env ─────────────────────────────────────────────────────────────────────
export const ENV = {
  supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL || '',
  supabaseAnonKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '',
  cloudinaryCloudName: process.env.EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME || '',
  cloudinaryUploadPreset: process.env.EXPO_PUBLIC_CLOUDINARY_UPLOAD_PRESET || '',
} as const;
