import { create } from 'zustand';
import { User } from '../types';
import { supabase } from '../services/supabase';
import { getUserProfile } from '../services/user.service';

interface AuthStore {
  user: User | null;
  session: any | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  needsProfileSetup: boolean;
  setUser: (user: User | null) => void;
  setSession: (session: any | null) => void;
  setLoading: (loading: boolean) => void;
  setNeedsProfileSetup: (needs: boolean) => void;
  initialize: () => Promise<void>;
  signOut: () => Promise<void>;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user: null,
  session: null,
  isLoading: true,
  isAuthenticated: false,
  needsProfileSetup: false,

  setUser: (user) => set({ user, isAuthenticated: !!user }),
  setSession: (session) => set({ session }),
  setLoading: (isLoading) => set({ isLoading }),
  setNeedsProfileSetup: (needsProfileSetup) => set({ needsProfileSetup }),

  initialize: async () => {
    set({ isLoading: true });
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        set({ session, isAuthenticated: true });

        // Load user profile
        const { data: profile } = await getUserProfile(session.user.id);
        if (profile) {
          set({ user: profile, needsProfileSetup: false });
        } else {
          set({ needsProfileSetup: true });
        }
      }
    } catch (err) {
      console.error('Auth init error:', err);
    } finally {
      set({ isLoading: false });
    }

    // Listen for auth changes
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        set({ session, isAuthenticated: true });
        const { data: profile } = await getUserProfile(session.user.id);
        if (profile) {
          set({ user: profile, needsProfileSetup: false });
        } else {
          set({ needsProfileSetup: true });
        }
      } else if (event === 'SIGNED_OUT') {
        set({ user: null, session: null, isAuthenticated: false, needsProfileSetup: false });
      }
    });
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, session: null, isAuthenticated: false, needsProfileSetup: false });
  },
}));
