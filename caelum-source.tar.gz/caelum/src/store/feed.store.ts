import { create } from 'zustand';
import { Post, Category } from '../types';
import { getFeedPosts } from '../services/post.service';

interface FeedStore {
  posts: Post[];
  selectedCategory: Category | null;
  isLoading: boolean;
  isRefreshing: boolean;
  hasMore: boolean;
  page: number;
  error: string | null;
  setCategory: (category: Category | null) => void;
  loadPosts: (refresh?: boolean) => Promise<void>;
  loadMore: () => Promise<void>;
}

export const useFeedStore = create<FeedStore>((set, get) => ({
  posts: [],
  selectedCategory: null,
  isLoading: false,
  isRefreshing: false,
  hasMore: true,
  page: 0,
  error: null,

  setCategory: async (category) => {
    set({ selectedCategory: category, posts: [], page: 0, hasMore: true });
    await get().loadPosts(true);
  },

  loadPosts: async (refresh = false) => {
    const { isLoading, isRefreshing } = get();
    if (isLoading || isRefreshing) return;

    if (refresh) {
      set({ isRefreshing: true, page: 0, hasMore: true });
    } else {
      set({ isLoading: true });
    }

    try {
      const { data, error } = await getFeedPosts(
        get().selectedCategory || undefined,
        refresh ? 0 : get().page,
        20
      );

      if (error) throw new Error(error);

      const newPosts = data || [];
      set(state => ({
        posts: refresh ? newPosts : [...state.posts, ...newPosts],
        hasMore: newPosts.length === 20,
        page: refresh ? 1 : state.page + 1,
        error: null,
      }));
    } catch (err: any) {
      set({ error: err.message });
    } finally {
      set({ isLoading: false, isRefreshing: false });
    }
  },

  loadMore: async () => {
    const { hasMore, isLoading } = get();
    if (!hasMore || isLoading) return;
    await get().loadPosts(false);
  },
}));
