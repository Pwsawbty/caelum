import * as ImageManipulator from 'expo-image-manipulator';
import { ENV, IMAGE_CONSTRAINTS } from '../constants';
import { CloudinaryUploadResponse } from '../types';

// ─── Build Cloudinary Optimized URL ──────────────────────────────────────────
export function buildCloudinaryUrl(
  publicId: string,
  options: {
    width?: number;
    height?: number;
    quality?: number;
    format?: string;
    crop?: string;
  } = {}
): string {
  const {
    width,
    height,
    quality = 'auto',
    format = 'auto',
    crop = 'fill',
  } = options;

  const transforms: string[] = [];
  if (width) transforms.push(`w_${width}`);
  if (height) transforms.push(`h_${height}`);
  transforms.push(`q_${quality}`);
  transforms.push(`f_${format}`);
  if (width || height) transforms.push(`c_${crop}`);

  const transformStr = transforms.join(',');
  return `https://res.cloudinary.com/${ENV.cloudinaryCloudName}/image/upload/${transformStr}/${publicId}`;
}

// ─── Generate Thumbnail URL ───────────────────────────────────────────────────
export function getThumbnailUrl(publicId: string): string {
  return buildCloudinaryUrl(publicId, {
    width: 400,
    height: 600,
    quality: 80,
    format: 'webp',
  });
}

// ─── Compress & Validate Image ────────────────────────────────────────────────
export async function processImageForUpload(
  uri: string
): Promise<{ uri: string; width: number; height: number; error: string | null }> {
  try {
    // First, get original dimensions
    const originalInfo = await ImageManipulator.manipulateAsync(uri, [], {
      compress: 1,
      format: ImageManipulator.SaveFormat.JPEG,
    });

    let targetWidth = originalInfo.width;
    let targetHeight = originalInfo.height;

    // Scale down if exceeds constraints
    if (targetWidth > IMAGE_CONSTRAINTS.maxWidth || targetHeight > IMAGE_CONSTRAINTS.maxHeight) {
      const widthRatio = IMAGE_CONSTRAINTS.maxWidth / targetWidth;
      const heightRatio = IMAGE_CONSTRAINTS.maxHeight / targetHeight;
      const ratio = Math.min(widthRatio, heightRatio);
      targetWidth = Math.floor(targetWidth * ratio);
      targetHeight = Math.floor(targetHeight * ratio);
    }

    // Process image
    const result = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: targetWidth, height: targetHeight } }],
      {
        compress: 0.85,
        format: ImageManipulator.SaveFormat.JPEG,
      }
    );

    return {
      uri: result.uri,
      width: result.width,
      height: result.height,
      error: null,
    };
  } catch (err: any) {
    return { uri: '', width: 0, height: 0, error: err.message };
  }
}

// ─── Upload to Cloudinary ─────────────────────────────────────────────────────
export async function uploadToCloudinary(
  imageUri: string,
  folder: string = 'caelum/posts'
): Promise<{ data: CloudinaryUploadResponse | null; error: string | null }> {
  try {
    // Compress image first
    const { uri: processedUri, error: processError } = await processImageForUpload(imageUri);
    if (processError) throw new Error(processError);

    const formData = new FormData();
    formData.append('file', {
      uri: processedUri,
      type: 'image/jpeg',
      name: `upload_${Date.now()}.jpg`,
    } as any);
    formData.append('upload_preset', ENV.cloudinaryUploadPreset);
    formData.append('folder', folder);

    // Add eager transformation for thumbnail
    formData.append('eager', 'w_400,h_600,c_fill,q_80,f_webp');
    formData.append('eager_async', 'true');

    const response = await fetch(
      `https://api.cloudinary.com/v1_1/${ENV.cloudinaryCloudName}/image/upload`,
      {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || 'Upload failed');
    }

    const result = await response.json();

    return {
      data: {
        public_id: result.public_id,
        secure_url: result.secure_url,
        thumbnail_url: getThumbnailUrl(result.public_id),
        width: result.width,
        height: result.height,
        format: result.format,
        bytes: result.bytes,
      },
      error: null,
    };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Upload Profile Photo ─────────────────────────────────────────────────────
export async function uploadProfilePhoto(
  imageUri: string
): Promise<{ url: string | null; error: string | null }> {
  const { data, error } = await uploadToCloudinary(imageUri, 'caelum/profiles');
  if (error) return { url: null, error };

  const profileUrl = buildCloudinaryUrl(data!.public_id, {
    width: 200,
    height: 200,
    quality: 90,
    format: 'webp',
    crop: 'fill',
  });

  return { url: profileUrl, error: null };
}

// ─── Validate Image File ──────────────────────────────────────────────────────
export function validateImageFile(
  mimeType: string,
  fileSize?: number
): { valid: boolean; error: string | null } {
  if (!IMAGE_CONSTRAINTS.allowedMimeTypes.includes(mimeType as any)) {
    return {
      valid: false,
      error: 'Only JPG, PNG and WebP images are allowed.',
    };
  }
  if (fileSize && fileSize > IMAGE_CONSTRAINTS.maxFileSizeBytes) {
    return {
      valid: false,
      error: 'Image must be under 10MB.',
    };
  }
  return { valid: true, error: null };
}
