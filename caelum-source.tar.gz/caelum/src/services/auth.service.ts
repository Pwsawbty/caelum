import * as WebBrowser from 'expo-web-browser';
import * as AuthSession from 'expo-auth-session';
import { supabase } from './supabase';
import { User } from '../types';

WebBrowser.maybeCompleteAuthSession();

// ─── Google Auth ─────────────────────────────────────────────────────────────
export async function signInWithGoogle(): Promise<{ user: any; error: string | null }> {
  try {
    const redirectUrl = AuthSession.makeRedirectUri({ scheme: 'caelum' });

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        skipBrowserRedirect: true,
      },
    });

    if (error) throw error;

    const result = await WebBrowser.openAuthSessionAsync(
      data.url!,
      redirectUrl
    );

    if (result.type === 'success') {
      const { url } = result;
      await supabase.auth.exchangeCodeForSession(extractCode(url));
      const { data: { user } } = await supabase.auth.getUser();
      return { user, error: null };
    }

    return { user: null, error: 'Sign in cancelled' };
  } catch (err: any) {
    return { user: null, error: err.message || 'Google sign in failed' };
  }
}

function extractCode(url: string): string {
  const params = new URL(url).searchParams;
  return params.get('code') || '';
}

// ─── Sign Out ─────────────────────────────────────────────────────────────────
export async function signOut(): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signOut();
  return { error: error?.message || null };
}

// ─── Get Current Session ──────────────────────────────────────────────────────
export async function getCurrentSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

// ─── Get Current User ─────────────────────────────────────────────────────────
export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}
