import { supabase } from './supabase';
import { User, ApiResponse } from '../types';

// ─── Get Profile ─────────────────────────────────────────────────────────────
export async function getUserProfile(userId: string): Promise<ApiResponse<User>> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Create Profile ──────────────────────────────────────────────────────────
export async function createUserProfile(profile: Partial<User>): Promise<ApiResponse<User>> {
  try {
    const { data, error } = await supabase
      .from('users')
      .insert(profile)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Update Profile ──────────────────────────────────────────────────────────
export async function updateUserProfile(
  userId: string,
  updates: Partial<User>
): Promise<ApiResponse<User>> {
  try {
    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Check Username Available ────────────────────────────────────────────────
export async function checkUsernameAvailable(username: string): Promise<boolean> {
  const { count } = await supabase
    .from('users')
    .select('id', { count: 'exact', head: true })
    .eq('username', username.toLowerCase());
  return count === 0;
}

// ─── Get Creator Profile ─────────────────────────────────────────────────────
export async function getCreatorProfile(userId: string, currentUserId?: string) {
  try {
    // Get user
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (userError) throw userError;

    // Get posts
    const { data: posts } = await supabase
      .from('posts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    // Get follower count
    const { count: followersCount } = await supabase
      .from('follows')
      .select('id', { count: 'exact', head: true })
      .eq('following_id', userId);

    // Get following count
    const { count: followingCount } = await supabase
      .from('follows')
      .select('id', { count: 'exact', head: true })
      .eq('follower_id', userId);

    // Check if current user follows
    let isFollowing = false;
    if (currentUserId && currentUserId !== userId) {
      const { count } = await supabase
        .from('follows')
        .select('id', { count: 'exact', head: true })
        .eq('follower_id', currentUserId)
        .eq('following_id', userId);
      isFollowing = (count || 0) > 0;
    }

    return {
      data: {
        ...user,
        posts: posts || [],
        followers_count: followersCount || 0,
        following_count: followingCount || 0,
        is_following: isFollowing,
      },
      error: null,
    };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Follow / Unfollow ───────────────────────────────────────────────────────
export async function toggleFollow(
  followerId: string,
  followingId: string
): Promise<{ isFollowing: boolean; error: string | null }> {
  try {
    // Check existing follow
    const { count } = await supabase
      .from('follows')
      .select('id', { count: 'exact', head: true })
      .eq('follower_id', followerId)
      .eq('following_id', followingId);

    if ((count || 0) > 0) {
      // Unfollow
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', followerId)
        .eq('following_id', followingId);
      return { isFollowing: false, error: null };
    } else {
      // Follow
      await supabase
        .from('follows')
        .insert({ follower_id: followerId, following_id: followingId });
      return { isFollowing: true, error: null };
    }
  } catch (err: any) {
    return { isFollowing: false, error: err.message };
  }
}
