import { supabase } from './supabase';
import { Post, Category, ApiResponse } from '../types';

// ─── Get Feed Posts ───────────────────────────────────────────────────────────
export async function getFeedPosts(
  category?: Category,
  page = 0,
  limit = 20
): Promise<ApiResponse<Post[]>> {
  try {
    let query = supabase
      .from('posts')
      .select(`
        *,
        author:users(id, username, display_name, profile_photo)
      `)
      .order('created_at', { ascending: false })
      .range(page * limit, (page + 1) * limit - 1);

    if (category) {
      query = query.eq('category', category);
    }

    const { data, error } = await query;
    if (error) throw error;
    return { data: data as Post[], error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Get Single Post ──────────────────────────────────────────────────────────
export async function getPost(postId: string): Promise<ApiResponse<Post>> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:users(id, username, display_name, profile_photo, bio, instagram_url, facebook_url, website_url)
      `)
      .eq('id', postId)
      .single();

    if (error) throw error;
    return { data: data as Post, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Create Post ──────────────────────────────────────────────────────────────
export async function createPost(
  postData: Partial<Post>
): Promise<ApiResponse<Post>> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .insert(postData)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Delete Post ──────────────────────────────────────────────────────────────
export async function deletePost(postId: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase
      .from('posts')
      .delete()
      .eq('id', postId);

    if (error) throw error;
    return { error: null };
  } catch (err: any) {
    return { error: err.message };
  }
}

// ─── Search Posts ─────────────────────────────────────────────────────────────
export async function searchPosts(query: string): Promise<ApiResponse<Post[]>> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:users(id, username, display_name, profile_photo)
      `)
      .or(`title.ilike.%${query}%,description.ilike.%${query}%,prompt.ilike.%${query}%`)
      .order('created_at', { ascending: false })
      .limit(30);

    if (error) throw error;
    return { data: data as Post[], error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}

// ─── Get User Posts ───────────────────────────────────────────────────────────
export async function getUserPosts(userId: string): Promise<ApiResponse<Post[]>> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err.message };
  }
}
