// ─── User & Profile ─────────────────────────────────────────────────────────
export interface User {
  id: string;
  username: string;
  display_name: string;
  bio?: string;
  profile_photo?: string;
  instagram_url?: string;
  facebook_url?: string;
  website_url?: string;
  created_at: string;
}

// ─── Post ───────────────────────────────────────────────────────────────────
export type Category =
  | 'Cinematic'
  | 'Dreamcore'
  | 'Rain'
  | 'Countryside'
  | 'Sci-fi'
  | 'Nature'
  | 'Warm'
  | 'Neon';

export interface Post {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  prompt: string;
  workflow?: string;
  tool_used: string;
  category: Category;
  image_url: string;
  thumbnail_url: string;
  external_link?: string;
  tags?: string[];
  created_at: string;
  // Joined fields
  author?: User;
  is_saved?: boolean;
  is_following_author?: boolean;
}

// ─── Follow ──────────────────────────────────────────────────────────────────
export interface Follow {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
}

// ─── Creator Profile ─────────────────────────────────────────────────────────
export interface CreatorProfile extends User {
  posts: Post[];
  followers_count: number;
  following_count: number;
  is_following?: boolean;
}

// ─── Upload ──────────────────────────────────────────────────────────────────
export interface UploadFormData {
  image: {
    uri: string;
    type: string;
    name: string;
    width?: number;
    height?: number;
  };
  title: string;
  prompt: string;
  category: Category;
  tool_used: string;
  description?: string;
  external_link?: string;
  tags?: string[];
}

// ─── Auth ────────────────────────────────────────────────────────────────────
export interface AuthState {
  user: User | null;
  session: any | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

// ─── Navigation ──────────────────────────────────────────────────────────────
export type RootStackParamList = {
  '(auth)': undefined;
  '(tabs)': undefined;
  'viewer/[id]': { id: string };
  'profile/[id]': { id: string };
  'profile-setup': undefined;
};

export type TabParamList = {
  index: undefined;
  upload: undefined;
  profile: undefined;
};

// ─── API Response ────────────────────────────────────────────────────────────
export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
}

// ─── Cloudinary ──────────────────────────────────────────────────────────────
export interface CloudinaryUploadResponse {
  public_id: string;
  secure_url: string;
  thumbnail_url?: string;
  width: number;
  height: number;
  format: string;
  bytes: number;
}
