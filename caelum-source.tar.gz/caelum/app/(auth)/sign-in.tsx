import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { signInWithGoogle } from '../../src/services/auth.service';
import { CaelumText } from '../../src/components/common/CaelumText';
import { COLORS, SPACING, RADIUS } from '../../src/constants';
import { useAuthStore } from '../../src/store/auth.store';

const { width, height } = Dimensions.get('window');

// Atmospheric background images (Cloudinary CDN)
const BG_IMAGES = [
  'https://res.cloudinary.com/demo/image/upload/w_800,q_auto,f_auto/landscapes/landscapes_01.jpg',
  'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=80',
  'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80',
  'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&q=80',
];

export default function SignInScreen() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bgIndex, setBgIndex] = useState(0);
  const { setUser, setSession, setNeedsProfileSetup } = useAuthStore();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(40)).current;
  const logoFade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Entrance animation
    Animated.sequence([
      Animated.timing(logoFade, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 600,
          useNativeDriver: true,
        }),
      ]),
    ]).start();

    // Cycle background images
    const interval = setInterval(() => {
      setBgIndex(prev => (prev + 1) % BG_IMAGES.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError(null);

    const { user, error: signInError } = await signInWithGoogle();

    if (signInError) {
      setError(signInError);
      setIsLoading(false);
      return;
    }

    if (user) {
      // Auth store will handle redirect via onAuthStateChange
      router.replace('/');
    }
    setIsLoading(false);
  };

  return (
    <View style={styles.container}>
      {/* Background image */}
      <Image
        source={{ uri: BG_IMAGES[bgIndex] }}
        style={StyleSheet.absoluteFillObject}
        contentFit="cover"
        transition={2000}
      />

      {/* Deep overlay */}
      <LinearGradient
        colors={[
          'rgba(5,5,7,0.3)',
          'rgba(5,5,7,0.6)',
          'rgba(5,5,7,0.95)',
        ]}
        locations={[0, 0.4, 1]}
        style={StyleSheet.absoluteFillObject}
      />

      <SafeAreaView style={styles.safeArea}>
        {/* Top brand */}
        <Animated.View style={[styles.brand, { opacity: logoFade }]}>
          <CaelumText
            style={styles.logoMark}
          >
            ✦
          </CaelumText>
          <CaelumText
            style={styles.logoText}
          >
            CAELUM
          </CaelumText>
        </Animated.View>

        {/* Bottom CTA */}
        <Animated.View
          style={[
            styles.bottom,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <CaelumText
            variant="heading"
            weight="light"
            style={styles.headline}
          >
            Discover cinematic{'\n'}AI atmospheres
          </CaelumText>

          <CaelumText
            variant="body"
            color="muted"
            style={styles.subline}
          >
            A curated gallery of atmospheric AI visuals,{'\n'}
            prompts, and creative workflows.
          </CaelumText>

          {/* Google Sign In */}
          <TouchableOpacity
            onPress={handleGoogleSignIn}
            disabled={isLoading}
            activeOpacity={0.85}
            style={[styles.googleButton, isLoading && { opacity: 0.7 }]}
          >
            <BlurView intensity={0} style={styles.googleInner}>
              {isLoading ? (
                <CaelumText weight="medium" style={styles.googleText}>
                  Signing in...
                </CaelumText>
              ) : (
                <>
                  <View style={styles.googleIcon}>
                    <CaelumText style={{ fontSize: 18 }}>G</CaelumText>
                  </View>
                  <CaelumText weight="medium" style={styles.googleText}>
                    Continue with Google
                  </CaelumText>
                </>
              )}
            </BlurView>
          </TouchableOpacity>

          {error && (
            <CaelumText
              variant="caption"
              style={{ color: COLORS.aurora.rose, textAlign: 'center', marginTop: SPACING.md }}
            >
              {error}
            </CaelumText>
          )}

          <CaelumText
            variant="label"
            color="muted"
            style={styles.legal}
          >
            By continuing, you agree to our Terms of Service{'\n'}and Privacy Policy
          </CaelumText>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  safeArea: {
    flex: 1,
    justifyContent: 'space-between',
    padding: SPACING.xl,
  },
  brand: {
    alignItems: 'center',
    paddingTop: SPACING['2xl'],
  },
  logoMark: {
    fontSize: 28,
    color: COLORS.offWhite,
    marginBottom: SPACING.sm,
  },
  logoText: {
    fontSize: 14,
    letterSpacing: 10,
    color: COLORS.mistLight,
    fontWeight: '300',
  },
  bottom: {
    paddingBottom: SPACING['2xl'],
  },
  headline: {
    fontSize: 32,
    lineHeight: 40,
    marginBottom: SPACING.lg,
    color: COLORS.offWhite,
  },
  subline: {
    lineHeight: 24,
    marginBottom: SPACING['3xl'],
  },
  googleButton: {
    borderRadius: RADIUS.full,
    overflow: 'hidden',
    marginBottom: SPACING.lg,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    backgroundColor: 'rgba(255,255,255,0.95)',
  },
  googleInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.md + 4,
    paddingHorizontal: SPACING.xl,
    gap: SPACING.md,
  },
  googleIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  googleText: {
    fontSize: 16,
    color: '#1a1a1a',
  },
  legal: {
    textAlign: 'center',
    lineHeight: 18,
    marginTop: SPACING.md,
  },
});
