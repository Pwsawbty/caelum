import React, { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { PostViewer } from '../../src/components/viewer/PostViewer';
import { LoadingScreen } from '../../src/components/common/LoadingScreen';
import { EmptyState } from '../../src/components/common/EmptyState';
import { CaelumButton } from '../../src/components/common/CaelumButton';
import { COLORS } from '../../src/constants';
import { getPost } from '../../src/services/post.service';
import { useAuthStore } from '../../src/store/auth.store';
import { Post } from '../../src/types';

export default function ViewerScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuthStore();
  const [post, setPost] = useState<Post | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) loadPost(id);
  }, [id]);

  const loadPost = async (postId: string) => {
    setIsLoading(true);
    const { data, error: fetchError } = await getPost(postId);
    if (fetchError) {
      setError(fetchError);
    } else {
      // Check if user follows the author
      if (data && user) {
        data.is_following_author = false; // would check in real app
      }
      setPost(data);
    }
    setIsLoading(false);
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <LoadingScreen />
      </View>
    );
  }

  if (error || !post) {
    return (
      <View style={styles.container}>
        <EmptyState
          icon="⚠"
          title="Failed to load"
          message={error || "This atmosphere could not be found."}
          action={
            <CaelumButton
              title="Go Back"
              onPress={() => router.back()}
              variant="secondary"
            />
          }
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <PostViewer post={post} onClose={() => router.back()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
});
