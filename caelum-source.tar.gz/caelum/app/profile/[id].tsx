import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Linking,
} from 'react-native';
import { Image } from 'expo-image';
import { useLocalSearchParams, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { CaelumText } from '../../src/components/common/CaelumText';
import { Avatar } from '../../src/components/common/Avatar';
import { EmptyState } from '../../src/components/common/EmptyState';
import { LoadingScreen } from '../../src/components/common/LoadingScreen';
import { COLORS, SPACING, RADIUS, CATEGORY_COLORS } from '../../src/constants';
import { getCreatorProfile, toggleFollow } from '../../src/services/user.service';
import { useAuthStore } from '../../src/store/auth.store';
import { CreatorProfile, Post } from '../../src/types';

const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - SPACING.md * 2 - SPACING.xs * 2) / 3;

export default function CreatorProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuthStore();
  const [profile, setProfile] = useState<CreatorProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);

  useEffect(() => {
    if (id) loadProfile(id);
  }, [id]);

  const loadProfile = async (profileId: string) => {
    setIsLoading(true);
    const { data } = await getCreatorProfile(profileId, user?.id);
    if (data) {
      setProfile(data);
      setIsFollowing(data.is_following || false);
    }
    setIsLoading(false);
  };

  const handleFollow = async () => {
    if (!user || !profile) return;
    setFollowLoading(true);
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const { isFollowing: newState } = await toggleFollow(user.id, profile.id);
    setIsFollowing(newState);
    setProfile(prev => prev ? {
      ...prev,
      followers_count: newState
        ? prev.followers_count + 1
        : prev.followers_count - 1,
    } : null);
    setFollowLoading(false);
  };

  const handlePostPress = (post: Post) => {
    router.push(`/viewer/${post.id}`);
  };

  const openLink = (url: string) => {
    if (!url.startsWith('http')) url = `https://${url}`;
    Linking.openURL(url);
  };

  if (isLoading) {
    return <LoadingScreen message="Loading creator..." />;
  }

  if (!profile) {
    return (
      <View style={styles.container}>
        <EmptyState icon="⚠" title="Creator not found" />
      </View>
    );
  }

  const posts = profile.posts || [];
  const isOwnProfile = user?.id === profile.id;

  return (
    <View style={styles.container}>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Top nav */}
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <Ionicons name="chevron-back" size={24} color={COLORS.mistLight} />
            </TouchableOpacity>
            <CaelumText variant="label" weight="semibold" color="muted" style={{ letterSpacing: 2 }}>
              CREATOR
            </CaelumText>
            <View style={{ width: 40 }} />
          </View>

          {/* Profile Info */}
          <View style={styles.profileSection}>
            <Avatar
              uri={profile.profile_photo}
              displayName={profile.display_name}
              size={92}
            />

            <CaelumText variant="heading" weight="semibold" style={styles.displayName}>
              {profile.display_name}
            </CaelumText>
            <CaelumText variant="body" color="muted" style={{ marginBottom: SPACING.md }}>
              @{profile.username}
            </CaelumText>

            {profile.bio && (
              <CaelumText
                variant="body"
                color="secondary"
                style={styles.bio}
              >
                {profile.bio}
              </CaelumText>
            )}

            {/* Stats */}
            <View style={styles.statsRow}>
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {posts.length}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>WORKS</CaelumText>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {profile.followers_count}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>FOLLOWERS</CaelumText>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {profile.following_count}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>FOLLOWING</CaelumText>
              </View>
            </View>

            {/* Follow button (not own profile) */}
            {!isOwnProfile && (
              <TouchableOpacity
                onPress={handleFollow}
                disabled={followLoading}
                style={[
                  styles.followButton,
                  isFollowing && styles.followingButton,
                ]}
              >
                <CaelumText
                  weight="semibold"
                  style={{
                    color: isFollowing ? COLORS.mistLight : COLORS.void,
                    fontSize: 15,
                  }}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </CaelumText>
              </TouchableOpacity>
            )}

            {/* Social links */}
            {(profile.instagram_url || profile.facebook_url || profile.website_url) && (
              <View style={styles.socialRow}>
                {profile.instagram_url && (
                  <TouchableOpacity
                    style={styles.socialChip}
                    onPress={() => openLink(profile.instagram_url!)}
                  >
                    <Ionicons name="logo-instagram" size={14} color={COLORS.aurora.purple} />
                    <CaelumText variant="label" style={{ color: COLORS.aurora.purple }}>Instagram</CaelumText>
                  </TouchableOpacity>
                )}
                {profile.facebook_url && (
                  <TouchableOpacity
                    style={styles.socialChip}
                    onPress={() => openLink(profile.facebook_url!)}
                  >
                    <Ionicons name="logo-facebook" size={14} color={COLORS.aurora.blue} />
                    <CaelumText variant="label" style={{ color: COLORS.aurora.blue }}>Facebook</CaelumText>
                  </TouchableOpacity>
                )}
                {profile.website_url && (
                  <TouchableOpacity
                    style={styles.socialChip}
                    onPress={() => openLink(profile.website_url!)}
                  >
                    <Ionicons name="globe-outline" size={14} color={COLORS.mistLight} />
                    <CaelumText variant="label" color="secondary">Website</CaelumText>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </View>

          {/* Works Grid */}
          <View style={styles.gridSection}>
            <CaelumText
              variant="label"
              weight="semibold"
              color="muted"
              style={styles.gridTitle}
            >
              ATMOSPHERES
            </CaelumText>

            {posts.length === 0 ? (
              <EmptyState
                icon="✦"
                title="No atmospheres yet"
                message="This creator hasn't shared any works yet."
              />
            ) : (
              <View style={styles.grid}>
                {posts.map(post => (
                  <TouchableOpacity
                    key={post.id}
                    onPress={() => handlePostPress(post)}
                    style={styles.gridItem}
                    activeOpacity={0.85}
                  >
                    <Image
                      source={{ uri: post.thumbnail_url || post.image_url }}
                      style={styles.gridImage}
                      contentFit="cover"
                      transition={300}
                    />
                    <LinearGradient
                      colors={['transparent', 'rgba(5,5,7,0.6)']}
                      style={styles.gridOverlay}
                    />
                    <View style={styles.gridCategoryDot}>
                      <View style={[styles.dot, { backgroundColor: CATEGORY_COLORS[post.category] }]} />
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
  },
  backButton: {
    padding: SPACING.xs,
  },
  profileSection: {
    alignItems: 'center',
    padding: SPACING.xl,
    paddingTop: SPACING['2xl'],
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
  },
  displayName: {
    marginTop: SPACING.lg,
    marginBottom: SPACING.xs,
  },
  bio: {
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: SPACING.xl,
    paddingHorizontal: SPACING.xl,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.xl,
    padding: SPACING.xl,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    marginBottom: SPACING.xl,
    width: '100%',
  },
  stat: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: COLORS.glassBorder,
  },
  statLabel: {
    letterSpacing: 1,
    marginTop: 4,
  },
  followButton: {
    backgroundColor: COLORS.offWhite,
    paddingHorizontal: SPACING['3xl'],
    paddingVertical: SPACING.md,
    borderRadius: RADIUS.full,
    marginBottom: SPACING.xl,
    minWidth: 160,
    alignItems: 'center',
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  socialRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    justifyContent: 'center',
    marginTop: SPACING.sm,
  },
  socialChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 2,
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.full,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  gridSection: {
    padding: SPACING.md,
    paddingTop: SPACING.xl,
  },
  gridTitle: {
    letterSpacing: 2,
    marginBottom: SPACING.md,
    paddingLeft: SPACING.xs,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.xs,
  },
  gridItem: {
    width: GRID_ITEM_SIZE,
    height: GRID_ITEM_SIZE * 1.3,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
    backgroundColor: COLORS.obsidianLight,
  },
  gridImage: {
    width: '100%',
    height: '100%',
  },
  gridOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '40%',
  },
  gridCategoryDot: {
    position: 'absolute',
    bottom: 6,
    right: 6,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
});
