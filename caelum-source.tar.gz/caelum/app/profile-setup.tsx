import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { CaelumText } from '../src/components/common/CaelumText';
import { CaelumInput } from '../src/components/common/CaelumInput';
import { CaelumButton } from '../src/components/common/CaelumButton';
import { COLORS, SPACING, RADIUS } from '../src/constants';
import { createUserProfile, checkUsernameAvailable } from '../src/services/user.service';
import { uploadProfilePhoto } from '../src/services/cloudinary.service';
import { useAuthStore } from '../src/store/auth.store';
import { supabase } from '../src/services/supabase';

interface FormData {
  username: string;
  display_name: string;
  bio: string;
  instagram_url: string;
  facebook_url: string;
  website_url: string;
}

interface FormErrors {
  username?: string;
  display_name?: string;
}

export default function ProfileSetupScreen() {
  const { session, setUser, setNeedsProfileSetup } = useAuthStore();
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [form, setForm] = useState<FormData>({
    username: '',
    display_name: '',
    bio: '',
    instagram_url: '',
    facebook_url: '',
    website_url: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});

  const updateField = (key: keyof FormData, value: string) => {
    setForm(prev => ({ ...prev, [key]: value }));
    if (errors[key as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [key]: undefined }));
    }
  };

  const pickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow access to your photos.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });

    if (!result.canceled && result.assets[0]) {
      setPhotoUri(result.assets[0].uri);
    }
  };

  const validate = async (): Promise<boolean> => {
    const newErrors: FormErrors = {};

    if (!form.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (!/^[a-z0-9_]{3,20}$/.test(form.username.toLowerCase())) {
      newErrors.username = '3–20 chars, lowercase letters, numbers, underscores only';
    } else {
      const isAvailable = await checkUsernameAvailable(form.username.toLowerCase());
      if (!isAvailable) {
        newErrors.username = 'This username is already taken';
      }
    }

    if (!form.display_name.trim()) {
      newErrors.display_name = 'Display name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!session) return;

    const isValid = await validate();
    if (!isValid) return;

    setIsLoading(true);
    try {
      let profilePhotoUrl: string | undefined;

      // Upload photo if selected
      if (photoUri) {
        const { url, error: uploadError } = await uploadProfilePhoto(photoUri);
        if (uploadError) {
          Alert.alert('Photo Upload Failed', uploadError);
          setIsLoading(false);
          return;
        }
        profilePhotoUrl = url || undefined;
      }

      // Create profile
      const { data: profile, error } = await createUserProfile({
        id: session.user.id,
        username: form.username.toLowerCase(),
        display_name: form.display_name.trim(),
        bio: form.bio.trim() || undefined,
        profile_photo: profilePhotoUrl,
        instagram_url: form.instagram_url.trim() || undefined,
        facebook_url: form.facebook_url.trim() || undefined,
        website_url: form.website_url.trim() || undefined,
      });

      if (error) {
        Alert.alert('Error', error);
        return;
      }

      setUser(profile!);
      setNeedsProfileSetup(false);
      router.replace('/(tabs)');
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[COLORS.obsidian, COLORS.void]}
        style={StyleSheet.absoluteFillObject}
      />

      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Header */}
            <View style={styles.header}>
              <CaelumText style={{ fontSize: 24, color: COLORS.offWhite, letterSpacing: 4 }}>
                ✦
              </CaelumText>
              <CaelumText
                variant="heading"
                weight="light"
                style={styles.headerTitle}
              >
                Create your profile
              </CaelumText>
              <CaelumText variant="body" color="muted" style={{ textAlign: 'center' }}>
                Join the Caelum creator community
              </CaelumText>
            </View>

            {/* Avatar Picker */}
            <TouchableOpacity
              onPress={pickPhoto}
              style={styles.avatarPicker}
              activeOpacity={0.8}
            >
              {photoUri ? (
                <Image
                  source={{ uri: photoUri }}
                  style={styles.avatarImage}
                  contentFit="cover"
                />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Ionicons name="camera-outline" size={28} color={COLORS.mistSoft} />
                  <CaelumText variant="caption" color="muted" style={{ marginTop: 6 }}>
                    Add photo
                  </CaelumText>
                </View>
              )}
              <View style={styles.avatarBadge}>
                <Ionicons name="add" size={14} color={COLORS.void} />
              </View>
            </TouchableOpacity>

            {/* Form */}
            <View style={styles.form}>
              <CaelumText
                variant="label"
                weight="semibold"
                color="muted"
                style={styles.sectionLabel}
              >
                REQUIRED
              </CaelumText>

              <CaelumInput
                label="Username"
                placeholder="your_username"
                value={form.username}
                onChangeText={(v) => updateField('username', v.toLowerCase())}
                error={errors.username}
                autoCapitalize="none"
                autoCorrect={false}
              />

              <CaelumInput
                label="Display Name"
                placeholder="Your Name"
                value={form.display_name}
                onChangeText={(v) => updateField('display_name', v)}
                error={errors.display_name}
              />

              <CaelumInput
                label="Bio"
                placeholder="Tell the world about your visual style..."
                value={form.bio}
                onChangeText={(v) => updateField('bio', v)}
                multiline
                numberOfLines={3}
                style={{ height: 80, textAlignVertical: 'top' }}
              />

              <CaelumText
                variant="label"
                weight="semibold"
                color="muted"
                style={[styles.sectionLabel, { marginTop: SPACING.lg }]}
              >
                OPTIONAL LINKS
              </CaelumText>

              <CaelumInput
                label="Instagram"
                placeholder="https://instagram.com/you"
                value={form.instagram_url}
                onChangeText={(v) => updateField('instagram_url', v)}
                autoCapitalize="none"
                keyboardType="url"
              />

              <CaelumInput
                label="Facebook"
                placeholder="https://facebook.com/you"
                value={form.facebook_url}
                onChangeText={(v) => updateField('facebook_url', v)}
                autoCapitalize="none"
                keyboardType="url"
              />

              <CaelumInput
                label="Website"
                placeholder="https://yourwebsite.com"
                value={form.website_url}
                onChangeText={(v) => updateField('website_url', v)}
                autoCapitalize="none"
                keyboardType="url"
              />
            </View>

            {/* Submit */}
            <CaelumButton
              title="Enter Caelum"
              onPress={handleSubmit}
              isLoading={isLoading}
              fullWidth
              style={{ marginTop: SPACING.xl }}
            />

            <View style={{ height: SPACING['3xl'] }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  scroll: {
    padding: SPACING.xl,
    paddingTop: SPACING['3xl'],
  },
  header: {
    alignItems: 'center',
    marginBottom: SPACING['3xl'],
    gap: SPACING.md,
  },
  headerTitle: {
    textAlign: 'center',
  },
  avatarPicker: {
    alignSelf: 'center',
    marginBottom: SPACING['3xl'],
    position: 'relative',
  },
  avatarImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 2,
    borderColor: COLORS.glassBorder,
  },
  avatarPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: COLORS.obsidianLight,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.offWhite,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.void,
  },
  form: {},
  sectionLabel: {
    letterSpacing: 1.5,
    marginBottom: SPACING.md,
  },
});
