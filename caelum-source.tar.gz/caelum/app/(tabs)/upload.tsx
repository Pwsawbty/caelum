import React, { useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { CaelumText } from '../../src/components/common/CaelumText';
import { CaelumInput } from '../../src/components/common/CaelumInput';
import { CaelumButton } from '../../src/components/common/CaelumButton';
import { COLORS, SPACING, RADIUS, CATEGORIES, CATEGORY_COLORS, IMAGE_CONSTRAINTS } from '../../src/constants';
import { uploadToCloudinary, validateImageFile, getThumbnailUrl } from '../../src/services/cloudinary.service';
import { createPost } from '../../src/services/post.service';
import { useAuthStore } from '../../src/store/auth.store';
import { Category } from '../../src/types';

const { width } = Dimensions.get('window');
const IMAGE_PREVIEW_HEIGHT = 220;

const TOOLS = ['Midjourney', 'DALL-E 3', 'Stable Diffusion', 'Firefly', 'Ideogram', 'Leonardo', 'Flux', 'Kling', 'Other'];

interface UploadForm {
  title: string;
  prompt: string;
  category: Category | null;
  tool_used: string;
  description: string;
  external_link: string;
  tags: string;
}

interface UploadErrors {
  title?: string;
  prompt?: string;
  category?: string;
  tool_used?: string;
  image?: string;
}

export default function UploadScreen() {
  const { user } = useAuthStore();
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [form, setForm] = useState<UploadForm>({
    title: '',
    prompt: '',
    category: null,
    tool_used: '',
    description: '',
    external_link: '',
    tags: '',
  });
  const [errors, setErrors] = useState<UploadErrors>({});

  const updateField = (key: keyof UploadForm, value: string | Category) => {
    setForm(prev => ({ ...prev, [key]: value }));
    if (errors[key as keyof UploadErrors]) {
      setErrors(prev => ({ ...prev, [key]: undefined }));
    }
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow access to your photo library.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 1,
      exif: false,
    });

    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];

      // Validate
      const { valid, error } = validateImageFile(asset.mimeType || 'image/jpeg', asset.fileSize);
      if (!valid) {
        setErrors(prev => ({ ...prev, image: error! }));
        return;
      }

      // Check dimensions
      if (asset.width && asset.width > IMAGE_CONSTRAINTS.maxWidth * 1.5) {
        Alert.alert(
          'Image Too Wide',
          `Maximum width is ${IMAGE_CONSTRAINTS.maxWidth}px. Your image will be automatically scaled.`
        );
      }

      setImageUri(asset.uri);
      setErrors(prev => ({ ...prev, image: undefined }));
    }
  };

  const validate = (): boolean => {
    const newErrors: UploadErrors = {};
    if (!imageUri) newErrors.image = 'Please select an image';
    if (!form.title.trim()) newErrors.title = 'Title is required';
    if (!form.prompt.trim()) newErrors.prompt = 'Prompt is required';
    if (!form.category) newErrors.category = 'Please select a category';
    if (!form.tool_used) newErrors.tool_used = 'Please select the tool used';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!user || !validate()) return;

    setIsUploading(true);
    setUploadProgress(10);

    try {
      // Upload to Cloudinary
      setUploadProgress(30);
      const { data: cloudData, error: uploadError } = await uploadToCloudinary(imageUri!);

      if (uploadError || !cloudData) {
        Alert.alert('Upload Failed', uploadError || 'Could not upload image. Please try again.');
        return;
      }

      setUploadProgress(70);

      // Parse tags
      const tags = form.tags
        .split(',')
        .map(t => t.trim().toLowerCase())
        .filter(Boolean);

      // Create post in Supabase
      const { data: post, error: postError } = await createPost({
        user_id: user.id,
        title: form.title.trim(),
        prompt: form.prompt.trim(),
        category: form.category!,
        tool_used: form.tool_used,
        image_url: cloudData.secure_url,
        thumbnail_url: cloudData.thumbnail_url || getThumbnailUrl(cloudData.public_id),
        description: form.description.trim() || undefined,
        external_link: form.external_link.trim() || undefined,
        tags: tags.length > 0 ? tags : undefined,
      });

      setUploadProgress(100);

      if (postError) {
        Alert.alert('Error', postError);
        return;
      }

      Alert.alert(
        'Published!',
        'Your atmospheric creation has been shared with the community.',
        [{ text: 'View Feed', onPress: () => router.replace('/(tabs)') }]
      );
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View style={styles.header}>
            <CaelumText variant="title" weight="semibold">
              Share Creation
            </CaelumText>
            <TouchableOpacity onPress={() => router.back()}>
              <Ionicons name="close" size={24} color={COLORS.mistLight} />
            </TouchableOpacity>
          </View>

          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Image Picker */}
            <TouchableOpacity
              onPress={pickImage}
              style={styles.imagePicker}
              activeOpacity={0.8}
            >
              {imageUri ? (
                <>
                  <Image
                    source={{ uri: imageUri }}
                    style={styles.imagePreview}
                    contentFit="cover"
                  />
                  <View style={styles.imageEditOverlay}>
                    <Ionicons name="image-outline" size={20} color={COLORS.offWhite} />
                    <CaelumText variant="caption" style={{ color: COLORS.offWhite, marginLeft: 6 }}>
                      Change image
                    </CaelumText>
                  </View>
                </>
              ) : (
                <View style={styles.imagePlaceholder}>
                  <LinearGradient
                    colors={['rgba(74,124,247,0.05)', 'rgba(139,92,246,0.05)']}
                    style={StyleSheet.absoluteFillObject}
                  />
                  <Ionicons name="image-outline" size={40} color={COLORS.mistFaint} />
                  <CaelumText variant="body" color="muted" style={{ marginTop: SPACING.md }}>
                    Tap to select image
                  </CaelumText>
                  <CaelumText variant="caption" color="muted" style={{ marginTop: 4 }}>
                    JPG, PNG or WebP · Max 10MB
                  </CaelumText>
                  <CaelumText variant="label" color="muted" style={{ marginTop: 4 }}>
                    Max {IMAGE_CONSTRAINTS.maxWidth} × {IMAGE_CONSTRAINTS.maxHeight}px
                  </CaelumText>
                </View>
              )}
            </TouchableOpacity>

            {errors.image && (
              <CaelumText variant="caption" style={{ color: COLORS.aurora.rose, marginBottom: SPACING.md }}>
                {errors.image}
              </CaelumText>
            )}

            {/* Form */}
            <CaelumInput
              label="Title"
              placeholder="Name your atmospheric creation..."
              value={form.title}
              onChangeText={(v) => updateField('title', v)}
              error={errors.title}
              maxLength={80}
            />

            <CaelumInput
              label="Prompt"
              placeholder="Paste your full generation prompt..."
              value={form.prompt}
              onChangeText={(v) => updateField('prompt', v)}
              error={errors.prompt}
              multiline
              numberOfLines={5}
              style={{ height: 120, textAlignVertical: 'top' }}
            />

            {/* Category Selector */}
            <View style={styles.fieldGroup}>
              <CaelumText variant="label" weight="medium" color="muted" style={styles.fieldLabel}>
                CATEGORY
              </CaelumText>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={styles.chips}>
                  {CATEGORIES.map(cat => {
                    const isSelected = form.category === cat;
                    const color = CATEGORY_COLORS[cat];
                    return (
                      <TouchableOpacity
                        key={cat}
                        onPress={() => updateField('category', cat)}
                        style={[
                          styles.chip,
                          isSelected && {
                            backgroundColor: color + '20',
                            borderColor: color + '60',
                          },
                        ]}
                      >
                        <CaelumText
                          variant="caption"
                          style={{ color: isSelected ? color : COLORS.mistSoft }}
                          weight={isSelected ? 'semibold' : 'regular'}
                        >
                          {cat}
                        </CaelumText>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>
              {errors.category && (
                <CaelumText variant="caption" style={{ color: COLORS.aurora.rose, marginTop: 4 }}>
                  {errors.category}
                </CaelumText>
              )}
            </View>

            {/* Tool Selector */}
            <View style={[styles.fieldGroup, { marginTop: SPACING.lg }]}>
              <CaelumText variant="label" weight="medium" color="muted" style={styles.fieldLabel}>
                AI TOOL USED
              </CaelumText>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={styles.chips}>
                  {TOOLS.map(tool => {
                    const isSelected = form.tool_used === tool;
                    return (
                      <TouchableOpacity
                        key={tool}
                        onPress={() => updateField('tool_used', tool)}
                        style={[
                          styles.chip,
                          isSelected && {
                            backgroundColor: COLORS.aurora.blue + '20',
                            borderColor: COLORS.aurora.blue + '50',
                          },
                        ]}
                      >
                        <CaelumText
                          variant="caption"
                          style={{ color: isSelected ? COLORS.aurora.blue : COLORS.mistSoft }}
                          weight={isSelected ? 'semibold' : 'regular'}
                        >
                          {tool}
                        </CaelumText>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>
              {errors.tool_used && (
                <CaelumText variant="caption" style={{ color: COLORS.aurora.rose, marginTop: 4 }}>
                  {errors.tool_used}
                </CaelumText>
              )}
            </View>

            {/* Optional Fields */}
            <View style={{ marginTop: SPACING.xl }}>
              <CaelumText
                variant="label"
                weight="semibold"
                color="muted"
                style={[styles.fieldLabel, { marginBottom: SPACING.md }]}
              >
                OPTIONAL
              </CaelumText>

              <CaelumInput
                label="Description"
                placeholder="Add context, mood, or creative notes..."
                value={form.description}
                onChangeText={(v) => updateField('description', v)}
                multiline
                numberOfLines={3}
                style={{ height: 80, textAlignVertical: 'top' }}
              />

              <CaelumInput
                label="External Link"
                placeholder="https://..."
                value={form.external_link}
                onChangeText={(v) => updateField('external_link', v)}
                autoCapitalize="none"
                keyboardType="url"
              />

              <CaelumInput
                label="Tags"
                placeholder="cinematic, rain, moody, fog (comma separated)"
                value={form.tags}
                onChangeText={(v) => updateField('tags', v)}
                autoCapitalize="none"
              />
            </View>

            {/* Upload Progress */}
            {isUploading && (
              <View style={styles.progressContainer}>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: `${uploadProgress}%` }]} />
                </View>
                <CaelumText variant="caption" color="muted" style={{ marginTop: 8 }}>
                  {uploadProgress < 50 ? 'Uploading image...' : 'Publishing to feed...'}
                </CaelumText>
              </View>
            )}

            <CaelumButton
              title={isUploading ? `Uploading ${uploadProgress}%` : 'Publish to Caelum'}
              onPress={handleSubmit}
              isLoading={isUploading}
              fullWidth
              style={{ marginTop: SPACING.xl }}
            />

            <View style={{ height: 100 }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.xl,
    paddingVertical: SPACING.lg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
  },
  scroll: {
    padding: SPACING.xl,
  },
  imagePicker: {
    width: '100%',
    height: IMAGE_PREVIEW_HEIGHT,
    borderRadius: RADIUS.xl,
    marginBottom: SPACING.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  imagePreview: {
    width: '100%',
    height: '100%',
  },
  imageEditOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.md,
    backgroundColor: 'rgba(5,5,7,0.7)',
  },
  imagePlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: COLORS.obsidianLight,
    alignItems: 'center',
    justifyContent: 'center',
    borderStyle: 'dashed',
  },
  fieldGroup: {},
  fieldLabel: {
    letterSpacing: 1,
    marginBottom: SPACING.sm,
  },
  chips: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  chip: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 2,
    borderRadius: RADIUS.full,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    backgroundColor: COLORS.obsidianLight,
  },
  progressContainer: {
    marginTop: SPACING.lg,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 2,
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.full,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.aurora.blue,
    borderRadius: RADIUS.full,
  },
});
