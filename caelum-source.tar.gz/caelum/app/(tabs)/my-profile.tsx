import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Alert,
  FlatList,
} from 'react-native';
import { Image } from 'expo-image';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { CaelumText } from '../../src/components/common/CaelumText';
import { Avatar } from '../../src/components/common/Avatar';
import { EmptyState } from '../../src/components/common/EmptyState';
import { LoadingScreen } from '../../src/components/common/LoadingScreen';
import { COLORS, SPACING, RADIUS, CATEGORY_COLORS } from '../../src/constants';
import { getCreatorProfile } from '../../src/services/user.service';
import { useAuthStore } from '../../src/store/auth.store';
import { Post, CreatorProfile } from '../../src/types';
import { signOut } from '../../src/services/auth.service';

const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - SPACING.md * 2 - SPACING.xs * 2) / 3;

export default function MyProfileScreen() {
  const { user, signOut: storeSignOut } = useAuthStore();
  const [profile, setProfile] = useState<CreatorProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    if (!user) return;
    setIsLoading(true);
    const { data } = await getCreatorProfile(user.id, user.id);
    setProfile(data);
    setIsLoading(false);
  };

  const handleSignOut = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out of Caelum?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await storeSignOut();
          router.replace('/(auth)/sign-in');
        },
      },
    ]);
  };

  const handlePostPress = (post: Post) => {
    router.push(`/viewer/${post.id}`);
  };

  if (isLoading) {
    return <LoadingScreen message="Loading profile..." />;
  }

  const posts = profile?.posts || [];

  return (
    <View style={styles.container}>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Profile Header */}
          <View style={styles.profileHeader}>
            {/* Top actions */}
            <View style={styles.topBar}>
              <CaelumText variant="label" weight="semibold" color="muted" style={{ letterSpacing: 2 }}>
                PROFILE
              </CaelumText>
              <View style={styles.headerActions}>
                <TouchableOpacity style={styles.actionButton}>
                  <Ionicons name="settings-outline" size={20} color={COLORS.mistLight} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSignOut} style={styles.actionButton}>
                  <Ionicons name="log-out-outline" size={20} color={COLORS.mistLight} />
                </TouchableOpacity>
              </View>
            </View>

            {/* Avatar & Name */}
            <View style={styles.avatarSection}>
              <Avatar
                uri={user?.profile_photo}
                displayName={user?.display_name}
                size={88}
              />
              <CaelumText variant="heading" weight="semibold" style={styles.displayName}>
                {user?.display_name}
              </CaelumText>
              <CaelumText variant="body" color="muted">
                @{user?.username}
              </CaelumText>
              {user?.bio && (
                <CaelumText
                  variant="body"
                  color="secondary"
                  style={styles.bio}
                >
                  {user.bio}
                </CaelumText>
              )}
            </View>

            {/* Stats Row */}
            <View style={styles.statsRow}>
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {posts.length}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>
                  WORKS
                </CaelumText>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {profile?.followers_count || 0}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>
                  FOLLOWERS
                </CaelumText>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.stat}>
                <CaelumText variant="title" weight="bold" style={{ color: COLORS.offWhite }}>
                  {profile?.following_count || 0}
                </CaelumText>
                <CaelumText variant="label" color="muted" style={styles.statLabel}>
                  FOLLOWING
                </CaelumText>
              </View>
            </View>

            {/* Social Links */}
            {(user?.instagram_url || user?.facebook_url || user?.website_url) && (
              <View style={styles.socialRow}>
                {user.instagram_url && (
                  <TouchableOpacity style={styles.socialChip}>
                    <Ionicons name="logo-instagram" size={14} color={COLORS.aurora.purple} />
                    <CaelumText variant="label" style={{ color: COLORS.aurora.purple }}>Instagram</CaelumText>
                  </TouchableOpacity>
                )}
                {user.facebook_url && (
                  <TouchableOpacity style={styles.socialChip}>
                    <Ionicons name="logo-facebook" size={14} color={COLORS.aurora.blue} />
                    <CaelumText variant="label" style={{ color: COLORS.aurora.blue }}>Facebook</CaelumText>
                  </TouchableOpacity>
                )}
                {user.website_url && (
                  <TouchableOpacity style={styles.socialChip}>
                    <Ionicons name="globe-outline" size={14} color={COLORS.mistLight} />
                    <CaelumText variant="label" color="secondary">Website</CaelumText>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </View>

          {/* Works Grid */}
          <View style={styles.gridSection}>
            <CaelumText
              variant="label"
              weight="semibold"
              color="muted"
              style={styles.gridTitle}
            >
              ATMOSPHERES
            </CaelumText>

            {posts.length === 0 ? (
              <EmptyState
                icon="✦"
                title="No atmospheres yet"
                message="Share your first cinematic AI creation with the Caelum community."
              />
            ) : (
              <View style={styles.grid}>
                {posts.map((post) => (
                  <TouchableOpacity
                    key={post.id}
                    onPress={() => handlePostPress(post)}
                    style={styles.gridItem}
                    activeOpacity={0.85}
                  >
                    <Image
                      source={{ uri: post.thumbnail_url || post.image_url }}
                      style={styles.gridImage}
                      contentFit="cover"
                      transition={300}
                    />
                    <LinearGradient
                      colors={['transparent', 'rgba(5,5,7,0.7)']}
                      style={styles.gridOverlay}
                    />
                    <View style={styles.gridCategoryDot}>
                      <View
                        style={[
                          styles.dot,
                          { backgroundColor: CATEGORY_COLORS[post.category] },
                        ]}
                      />
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <View style={{ height: 100 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  profileHeader: {
    padding: SPACING.xl,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING['2xl'],
  },
  headerActions: {
    flexDirection: 'row',
    gap: SPACING.md,
  },
  actionButton: {
    padding: SPACING.xs,
  },
  avatarSection: {
    alignItems: 'center',
    marginBottom: SPACING['2xl'],
  },
  displayName: {
    marginTop: SPACING.lg,
    marginBottom: SPACING.xs,
  },
  bio: {
    textAlign: 'center',
    marginTop: SPACING.md,
    lineHeight: 22,
    paddingHorizontal: SPACING.xl,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.xl,
    padding: SPACING.xl,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    marginBottom: SPACING.lg,
  },
  stat: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: COLORS.glassBorder,
  },
  statLabel: {
    letterSpacing: 1,
    marginTop: 4,
  },
  socialRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    justifyContent: 'center',
  },
  socialChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 2,
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.full,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  gridSection: {
    padding: SPACING.md,
    paddingTop: SPACING.xl,
  },
  gridTitle: {
    letterSpacing: 2,
    marginBottom: SPACING.md,
    paddingLeft: SPACING.xs,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.xs,
  },
  gridItem: {
    width: GRID_ITEM_SIZE,
    height: GRID_ITEM_SIZE * 1.3,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
    backgroundColor: COLORS.obsidianLight,
  },
  gridImage: {
    width: '100%',
    height: '100%',
  },
  gridOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '40%',
  },
  gridCategoryDot: {
    position: 'absolute',
    bottom: 6,
    right: 6,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
});
