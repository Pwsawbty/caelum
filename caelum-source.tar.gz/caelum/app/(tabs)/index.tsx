import React, { useEffect, useCallback, useState } from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  RefreshControl,
  StatusBar,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFeedStore } from '../../src/store/feed.store';
import { useAuthStore } from '../../src/store/auth.store';
import { MasonryGrid } from '../../src/components/feed/MasonryGrid';
import { CategoryTabs } from '../../src/components/feed/CategoryTabs';
import { CaelumText } from '../../src/components/common/CaelumText';
import { Avatar } from '../../src/components/common/Avatar';
import { EmptyState } from '../../src/components/common/EmptyState';
import { Post, Category } from '../../src/types';
import { COLORS, SPACING, RADIUS } from '../../src/constants';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const {
    posts,
    isLoading,
    isRefreshing,
    hasMore,
    selectedCategory,
    setCategory,
    loadPosts,
    loadMore,
  } = useFeedStore();

  const { user } = useAuthStore();
  const [searchVisible, setSearchVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadPosts(true);
  }, []);

  const handlePostPress = useCallback((post: Post) => {
    router.push(`/viewer/${post.id}`);
  }, []);

  const handleProfilePress = () => {
    router.push('/my-profile');
  };

  // Group posts for FlatList (masonry handled inside)
  const renderFeed = () => {
    if (isLoading && posts.length === 0) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={COLORS.mistLight} size="small" />
        </View>
      );
    }

    if (!isLoading && posts.length === 0) {
      return (
        <EmptyState
          icon="✦"
          title="No atmospheres yet"
          message="Be the first to share a cinematic creation in this category."
        />
      );
    }

    return null;
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Sticky Header */}
      <BlurView
        intensity={30}
        tint="dark"
        style={styles.header}
      >
        <View style={styles.headerContent}>
          {searchVisible ? (
            <View style={styles.searchBar}>
              <Ionicons name="search-outline" size={16} color={COLORS.mistSoft} />
              <TextInput
                placeholder="Search atmospheres, prompts..."
                placeholderTextColor={COLORS.mistFaint}
                style={styles.searchInput}
                value={searchQuery}
                onChangeText={setSearchQuery}
                autoFocus
              />
              <TouchableOpacity onPress={() => {
                setSearchVisible(false);
                setSearchQuery('');
              }}>
                <Ionicons name="close-circle" size={18} color={COLORS.mistSoft} />
              </TouchableOpacity>
            </View>
          ) : (
            <>
              {/* Logo */}
              <View style={styles.logoGroup}>
                <CaelumText style={styles.logoMark}>✦</CaelumText>
                <CaelumText style={styles.logoText}>CAELUM</CaelumText>
              </View>

              {/* Right icons */}
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={() => setSearchVisible(true)}
                  style={styles.iconButton}
                >
                  <Ionicons name="search-outline" size={22} color={COLORS.mistLight} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleProfilePress}
                  style={styles.iconButton}
                >
                  <Avatar
                    uri={user?.profile_photo}
                    displayName={user?.display_name}
                    size={32}
                  />
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>

        {/* Category tabs */}
        {!searchVisible && (
          <CategoryTabs
            selected={selectedCategory}
            onSelect={(cat) => setCategory(cat as Category | null)}
          />
        )}
      </BlurView>

      {/* Feed */}
      <FlatList
        data={[{ key: 'grid' }]}
        renderItem={() => (
          <MasonryGrid posts={posts} onPostPress={handlePostPress} />
        )}
        keyExtractor={() => 'grid'}
        contentContainerStyle={styles.feedContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={() => loadPosts(true)}
            tintColor={COLORS.mistLight}
            colors={[COLORS.mistLight]}
          />
        }
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        ListEmptyComponent={renderFeed()}
        ListFooterComponent={
          isLoading && posts.length > 0 ? (
            <View style={{ paddingVertical: 20, alignItems: 'center' }}>
              <ActivityIndicator color={COLORS.mistLight} size="small" />
            </View>
          ) : null
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.void,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    backgroundColor: 'rgba(5,5,7,0.85)',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
    paddingTop: Platform.OS === 'ios' ? 50 : 30,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.sm,
  },
  logoGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  logoMark: {
    fontSize: 18,
    color: COLORS.offWhite,
  },
  logoText: {
    fontSize: 14,
    letterSpacing: 6,
    color: COLORS.mistLight,
    fontWeight: '300',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  iconButton: {
    padding: SPACING.xs,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.obsidianLight,
    borderRadius: RADIUS.full,
    paddingHorizontal: SPACING.md,
    height: 40,
    gap: SPACING.sm,
  },
  searchInput: {
    flex: 1,
    color: COLORS.offWhite,
    fontSize: 14,
  },
  feedContent: {
    paddingTop: Platform.OS === 'ios' ? 160 : 140,
    paddingBottom: 100,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
  },
});
