import { Tabs } from 'expo-router';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../../src/constants';

function TabBarBackground() {
  return (
    <BlurView
      intensity={40}
      tint="dark"
      style={[StyleSheet.absoluteFillObject, { backgroundColor: 'rgba(5,5,7,0.85)' }]}
    />
  );
}

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarBackground: () => <TabBarBackground />,
        tabBarStyle: {
          position: 'absolute',
          borderTopWidth: 1,
          borderTopColor: COLORS.glassBorder,
          height: 80,
          paddingBottom: 16,
          backgroundColor: 'transparent',
          elevation: 0,
        },
        tabBarActiveTintColor: COLORS.offWhite,
        tabBarInactiveTintColor: COLORS.mistFaint,
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <Ionicons
              name={focused ? 'compass' : 'compass-outline'}
              size={26}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="upload"
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={styles.uploadButton}>
              <Ionicons name="add" size={28} color={COLORS.void} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="my-profile"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <Ionicons
              name={focused ? 'person' : 'person-outline'}
              size={24}
              color={color}
            />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  uploadButton: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: COLORS.offWhite,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.offWhite,
    shadowOpacity: 0.2,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
});
