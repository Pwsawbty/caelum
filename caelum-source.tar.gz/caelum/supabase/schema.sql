-- ============================================================
-- CAELUM — Supabase Database Schema
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── USERS TABLE ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.users (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username      TEXT UNIQUE NOT NULL,
  display_name  TEXT NOT NULL,
  bio           TEXT,
  profile_photo TEXT,
  instagram_url TEXT,
  facebook_url  TEXT,
  website_url   TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for username lookups
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON public.users(LOWER(username));

-- ─── POSTS TABLE ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.posts (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id        UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  description    TEXT,
  prompt         TEXT NOT NULL,
  workflow       TEXT,
  tool_used      TEXT NOT NULL,
  category       TEXT NOT NULL CHECK (
    category IN ('Cinematic','Dreamcore','Rain','Countryside','Sci-fi','Nature','Warm','Neon')
  ),
  image_url      TEXT NOT NULL,
  thumbnail_url  TEXT NOT NULL,
  external_link  TEXT,
  tags           TEXT[],
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_posts_user_id      ON public.posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_category     ON public.posts(category);
CREATE INDEX IF NOT EXISTS idx_posts_created_at   ON public.posts(created_at DESC);

-- Full-text search index
CREATE INDEX IF NOT EXISTS idx_posts_fts ON public.posts
  USING GIN (to_tsvector('english', title || ' ' || COALESCE(description,'') || ' ' || prompt));

-- ─── FOLLOWS TABLE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.follows (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id  UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id <> following_id)
);

CREATE INDEX IF NOT EXISTS idx_follows_follower   ON public.follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following  ON public.follows(following_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE public.users  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

-- ─── USERS policies ────────────────────────────────────────
-- Anyone can view user profiles
CREATE POLICY "public_profiles_view" ON public.users
  FOR SELECT USING (true);

-- Users can only insert/update their own profile
CREATE POLICY "own_profile_insert" ON public.users
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "own_profile_update" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- ─── POSTS policies ────────────────────────────────────────
-- Anyone can view posts
CREATE POLICY "public_posts_view" ON public.posts
  FOR SELECT USING (true);

-- Authenticated users can create posts
CREATE POLICY "auth_posts_insert" ON public.posts
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Users can only update/delete their own posts
CREATE POLICY "own_posts_update" ON public.posts
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "own_posts_delete" ON public.posts
  FOR DELETE USING (auth.uid() = user_id);

-- ─── FOLLOWS policies ──────────────────────────────────────
-- Anyone can view follows
CREATE POLICY "public_follows_view" ON public.follows
  FOR SELECT USING (true);

-- Authenticated users can follow/unfollow
CREATE POLICY "auth_follows_insert" ON public.follows
  FOR INSERT WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "auth_follows_delete" ON public.follows
  FOR DELETE USING (auth.uid() = follower_id);

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================

-- Auto-create user profile when auth user is created
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Profile is created manually in profile-setup screen
  -- This function is a placeholder for future automation
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- SEED DATA (optional, for testing)
-- ============================================================
-- Uncomment and run to populate sample data
/*
INSERT INTO public.users (id, username, display_name, bio) VALUES
  ('00000000-0000-0000-0000-000000000001', 'caelum_team', 'Caelum Team', 'Curators of atmospheric AI art.'),
  ('00000000-0000-0000-0000-000000000002', 'dreamer_ai', 'Dreamer AI', 'Exploring the boundaries of generative art.');
*/
