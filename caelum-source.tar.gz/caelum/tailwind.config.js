/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        // Core dark palette
        void: {
          DEFAULT: '#050507',
          50: '#0d0d12',
          100: '#0a0a0f',
          200: '#08080d',
        },
        obsidian: {
          DEFAULT: '#0f0f15',
          light: '#161620',
          mid: '#1a1a25',
          soft: '#1e1e2a',
        },
        mist: {
          DEFAULT: '#8b8fa8',
          light: '#a8acc4',
          soft: '#6b6f85',
          faint: '#3d3f50',
        },
        aurora: {
          blue: '#4a7cf7',
          purple: '#8b5cf6',
          teal: '#14b8a6',
          rose: '#f43f5e',
          amber: '#f59e0b',
        },
        glass: {
          DEFAULT: 'rgba(255,255,255,0.04)',
          border: 'rgba(255,255,255,0.08)',
          strong: 'rgba(255,255,255,0.10)',
        },
      },
      fontFamily: {
        sans: ['System'],
        mono: ['SpaceMono'],
      },
      borderRadius: {
        '2xl': '16px',
        '3xl': '24px',
        '4xl': '32px',
      },
    },
  },
  plugins: [],
};
