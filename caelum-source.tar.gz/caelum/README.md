# ✦ CAELUM — Atmospheric AI Discovery App

> A premium mobile-first platform for discovering cinematic AI-generated atmospheres, prompts, and creative workflows.

---

## ✦ App Overview

Caelum is a curated discovery platform built for creators and enthusiasts of atmospheric AI-generated imagery. Think Pinterest × Behance, but focused entirely on cinematic, immersive visual aesthetics — dark, quiet, and premium.

---

## 🗂 Project Structure

```
caelum/
├── app/                          # Expo Router screens
│   ├── _layout.tsx               # Root layout with auth guard
│   ├── index.tsx                 # Entry redirect
│   ├── profile-setup.tsx         # New user profile setup
│   ├── (auth)/
│   │   ├── _layout.tsx
│   │   └── sign-in.tsx           # Google sign-in screen
│   ├── (tabs)/
│   │   ├── _layout.tsx           # Tab bar with glassmorphism
│   │   ├── index.tsx             # Home feed (masonry grid)
│   │   ├── upload.tsx            # Upload creation
│   │   └── my-profile.tsx        # Own profile
│   ├── viewer/
│   │   └── [id].tsx              # Fullscreen immersive viewer
│   └── profile/
│       └── [id].tsx              # Creator profile
│
├── src/
│   ├── components/
│   │   ├── common/               # Reusable primitives
│   │   │   ├── CaelumText.tsx    # Typography component
│   │   │   ├── CaelumButton.tsx  # Multi-variant button
│   │   │   ├── CaelumInput.tsx   # Dark-themed input
│   │   │   ├── GlassPanel.tsx    # Glassmorphism container
│   │   │   ├── Avatar.tsx        # User avatar with fallback
│   │   │   ├── LoadingScreen.tsx # Animated loading state
│   │   │   └── EmptyState.tsx    # Empty/error state
│   │   ├── feed/
│   │   │   ├── PostCard.tsx      # Masonry grid card
│   │   │   ├── MasonryGrid.tsx   # 2-column masonry layout
│   │   │   └── CategoryTabs.tsx  # Horizontal category filter
│   │   ├── viewer/
│   │   │   └── PostViewer.tsx    # Fullscreen immersive viewer
│   │   ├── upload/               # Upload form components
│   │   └── profile/              # Profile components
│   ├── services/
│   │   ├── supabase.ts           # Supabase client
│   │   ├── auth.service.ts       # Google OAuth
│   │   ├── user.service.ts       # User/profile CRUD
│   │   ├── post.service.ts       # Posts CRUD
│   │   └── cloudinary.service.ts # Image upload & CDN
│   ├── store/
│   │   ├── auth.store.ts         # Auth state (Zustand)
│   │   └── feed.store.ts         # Feed state (Zustand)
│   ├── types/index.ts            # TypeScript interfaces
│   └── constants/index.ts        # Colors, spacing, categories
│
├── supabase/
│   └── schema.sql                # Full database schema + RLS
├── app.json                      # Expo configuration
├── babel.config.js               # Babel + NativeWind
├── tailwind.config.js            # Tailwind theme
├── metro.config.js               # Metro + NativeWind
├── global.css                    # Tailwind imports
├── tsconfig.json                 # TypeScript paths
└── .env.example                  # Environment template
```

---

## ⚡ Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Expo SDK 51 + Expo Router |
| Language | TypeScript |
| Styling | NativeWind v4 + Tailwind CSS |
| Backend | Supabase (Auth + PostgreSQL) |
| Images | Cloudinary (Upload + CDN + Thumbnails) |
| State | Zustand |
| Animations | React Native Reanimated v3 |
| UI | Expo Blur, Linear Gradient, Expo Image |

---

## 🚀 Setup Guide

### Prerequisites

- Node.js 18+
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- Expo Go app (iOS/Android) for testing
- Supabase account
- Cloudinary account

---

### Step 1: Clone & Install

```bash
git clone https://github.com/your-org/caelum.git
cd caelum
npm install
```

---

### Step 2: Supabase Setup

#### 2.1 Create Project

1. Go to [supabase.com](https://supabase.com) → New Project
2. Choose region closest to your users
3. Set a strong database password

#### 2.2 Run Database Schema

1. In Supabase Dashboard → **SQL Editor**
2. Copy the entire contents of `supabase/schema.sql`
3. Paste and run it

This creates:
- `users` table with profile fields
- `posts` table with all metadata
- `follows` table for the social graph
- Row Level Security policies
- Performance indexes

#### 2.3 Configure Google OAuth

1. Supabase Dashboard → **Authentication** → **Providers** → **Google**
2. Enable Google provider
3. In [Google Cloud Console](https://console.cloud.google.com):
   - Create a project → OAuth 2.0 credentials
   - Add **Authorized redirect URIs**:
     - `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`
   - Copy **Client ID** and **Client Secret**
4. Paste them into Supabase Google provider settings
5. In Supabase → **Authentication** → **URL Configuration**:
   - Add Site URL: `caelum://` (your app scheme)
   - Add Redirect URL: `caelum://*`

#### 2.4 Get API Keys

Go to Supabase Dashboard → **Settings** → **API**:
- Copy **Project URL** (SUPABASE_URL)
- Copy **anon/public** key (SUPABASE_ANON_KEY)

---

### Step 3: Cloudinary Setup

#### 3.1 Create Account

1. Sign up at [cloudinary.com](https://cloudinary.com)
2. Go to your **Dashboard** to find your Cloud Name

#### 3.2 Create Upload Preset

1. Settings → **Upload** → **Upload presets** → Add upload preset
2. Set **Signing Mode** to `Unsigned`
3. Name it: `caelum_upload`
4. Configure transformations:
   - Quality: `auto`
   - Format: `auto`
5. Under **Folder**: Set to `caelum`
6. Under **Eager Transformations**, add:
   - `w_400,h_600,c_fill,q_80,f_webp` (thumbnail)
7. Save preset

---

### Step 4: Environment Variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
EXPO_PUBLIC_SUPABASE_URL=https://xxxxxxxxxxxxxxxxxxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME=your-cloud-name
EXPO_PUBLIC_CLOUDINARY_UPLOAD_PRESET=caelum_upload
```

---

### Step 5: App Configuration

#### 5.1 iOS (app.json)

Replace `YOUR_IOS_REVERSED_CLIENT_ID` in `app.json` with your Google iOS client ID reversed:
```json
"config": {
  "googleSignIn": {
    "reservedClientId": "com.googleusercontent.apps.YOUR_CLIENT_ID"
  }
}
```

#### 5.2 Android (google-services.json)

1. In Google Cloud Console → Your Project → Download `google-services.json`
2. Place it in the root of the project
3. The `app.json` references it: `"googleServicesFile": "./google-services.json"`

---

### Step 6: Add App Assets

Replace placeholder files in `assets/images/`:
- `icon.png` — 1024×1024px app icon
- `splash.png` — 1242×2436px splash screen (dark background `#050507`)
- `adaptive-icon.png` — 1024×1024px Android adaptive icon
- `favicon.png` — 48×48px web favicon

---

### Step 7: Run the App

```bash
# Start Expo dev server
npx expo start

# Or run directly:
npx expo start --ios      # iOS Simulator
npx expo start --android  # Android Emulator
```

Scan the QR code with **Expo Go** on your phone.

---

## 📱 App Flow

```
Launch
  │
  ├── Not authenticated → Sign-In Screen (Google OAuth)
  │                           │
  │                           └── Authenticated
  │                                   │
  │                                   ├── No profile → Profile Setup
  │                                   └── Has profile → Home Feed
  │
Home Feed (Tabs)
  ├── Browse masonry grid by category
  ├── Tap post → Fullscreen Immersive Viewer
  │               ├── View full image
  │               ├── See creator info + Follow
  │               ├── Read full prompt
  │               └── Copy prompt
  ├── Upload tab → Add new atmospheric creation
  └── Profile tab → Own profile, works, stats
```

---

## 🎨 Design System

### Color Palette

| Token | Value | Usage |
|-------|-------|-------|
| `void` | `#050507` | Primary background |
| `obsidian` | `#0f0f15` | Cards, panels |
| `obsidianLight` | `#161620` | Input backgrounds |
| `offWhite` | `#E8E8F0` | Primary text |
| `mistLight` | `#a8acc4` | Secondary text |
| `mistSoft` | `#6b6f85` | Muted text |
| `aurora.blue` | `#4a7cf7` | Accent, links |
| `aurora.purple` | `#8b5cf6` | Dreamcore category |
| `glassBorder` | `rgba(255,255,255,0.08)` | Subtle borders |

### Categories & Colors

| Category | Color |
|----------|-------|
| Cinematic | `#4a7cf7` |
| Dreamcore | `#8b5cf6` |
| Rain | `#14b8a6` |
| Countryside | `#f59e0b` |
| Sci-fi | `#f43f5e` |
| Nature | `#22c55e` |
| Warm | `#f97316` |
| Neon | `#a855f7` |

---

## 🗃 Database Schema

### users
| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Auth user ID |
| username | TEXT (unique) | @handle |
| display_name | TEXT | Full name |
| bio | TEXT | Profile bio |
| profile_photo | TEXT | Cloudinary URL |
| instagram_url | TEXT | Optional link |
| facebook_url | TEXT | Optional link |
| website_url | TEXT | Optional link |
| created_at | TIMESTAMPTZ | |

### posts
| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Auto-generated |
| user_id | UUID (FK) | Author |
| title | TEXT | Post title |
| description | TEXT | Optional notes |
| prompt | TEXT | Full AI prompt |
| workflow | TEXT | Generation workflow |
| tool_used | TEXT | AI tool (Midjourney, etc.) |
| category | TEXT | Enum category |
| image_url | TEXT | Full Cloudinary URL |
| thumbnail_url | TEXT | Optimized thumbnail |
| external_link | TEXT | External resource |
| tags | TEXT[] | Searchable tags |
| created_at | TIMESTAMPTZ | |

### follows
| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | |
| follower_id | UUID (FK) | User who follows |
| following_id | UUID (FK) | User being followed |
| created_at | TIMESTAMPTZ | |

---

## 📦 Image Pipeline

```
User selects image
        │
        ▼
validateImageFile() — Check MIME type + size (≤10MB)
        │
        ▼
processImageForUpload() — Scale to ≤1080×1920, compress 85%
        │
        ▼
uploadToCloudinary() — POST to Cloudinary API
        │
        ├── secure_url → Full image (stored in posts.image_url)
        └── getThumbnailUrl() → 400×600 WebP thumbnail (stored in posts.thumbnail_url)
                │
                ▼
        CDN delivery via Cloudinary (global edge)
```

---

## 🔒 Security

- **Row Level Security**: All Supabase tables have RLS enabled
- **Unsigned preset**: Cloudinary upload preset is unsigned (fine for mobile)
- **Auth tokens**: Managed by Supabase/Google, stored in AsyncStorage with encryption
- **No secrets in code**: All keys via `EXPO_PUBLIC_*` env vars
- **User isolation**: Users can only modify their own posts/profile

---

## 🏗 Building for Production

### EAS Build (Recommended)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login
eas login

# Configure project
eas build:configure

# Build for iOS (App Store)
eas build --platform ios --profile production

# Build for Android (Play Store)
eas build --platform android --profile production
```

### Environment Variables for Production

In EAS Dashboard or `eas.json`:
```json
{
  "build": {
    "production": {
      "env": {
        "EXPO_PUBLIC_SUPABASE_URL": "https://...",
        "EXPO_PUBLIC_SUPABASE_ANON_KEY": "...",
        "EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME": "...",
        "EXPO_PUBLIC_CLOUDINARY_UPLOAD_PRESET": "..."
      }
    }
  }
}
```

---

## 🔧 Customization

### Adding New Categories

In `src/constants/index.ts`:
```typescript
export const CATEGORIES: Category[] = [
  ...existing,
  'YourNewCategory', // Add here
];
export const CATEGORY_COLORS = {
  ...existing,
  YourNewCategory: '#hexcolor',
};
```

Update the `posts` table check constraint in Supabase:
```sql
ALTER TABLE posts DROP CONSTRAINT posts_category_check;
ALTER TABLE posts ADD CONSTRAINT posts_category_check 
  CHECK (category IN ('Cinematic','Dreamcore','Rain',...,'YourNewCategory'));
```

### Adding New AI Tools

In `app/(tabs)/upload.tsx`, add to the `TOOLS` array:
```typescript
const TOOLS = [...existing, 'NewTool'];
```

---

## 📞 Support

Built with care for the atmospheric AI creative community.

- Design Language: Minimal dark UI, premium cinematic
- Focus: Immersive visual experience over social features
- Philosophy: Quality over quantity

---

*✦ Made for those who see atmosphere as art.*
